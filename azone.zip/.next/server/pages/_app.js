(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888];
exports.modules = {

/***/ 3195:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./context/auth/reducer.js
var reducer = __webpack_require__(1118);
// EXTERNAL MODULE: ./context/country/reducer.js
var country_reducer = __webpack_require__(3363);
// EXTERNAL MODULE: ./context/mappingCountry/reducer.js
var mappingCountry_reducer = __webpack_require__(5159);
// EXTERNAL MODULE: ./context/mappingCity/reducer.js
var mappingCity_reducer = __webpack_require__(3240);
// EXTERNAL MODULE: ./context/city/reducer.js
var city_reducer = __webpack_require__(8796);
// EXTERNAL MODULE: ./context/nationality/reducer.js
var nationality_reducer = __webpack_require__(6821);
// EXTERNAL MODULE: ./context/cityLocation/reducer.js
var cityLocation_reducer = __webpack_require__(4882);
// EXTERNAL MODULE: ./context/hotel/reducer.js
var hotel_reducer = __webpack_require__(2413);
// EXTERNAL MODULE: ./context/operatorMan/reducer.js
var operatorMan_reducer = __webpack_require__(7324);
// EXTERNAL MODULE: ./context/salesOffice/reducer.js
var salesOffice_reducer = __webpack_require__(3306);
// EXTERNAL MODULE: ./context/supplier/reducer.js
var supplier_reducer = __webpack_require__(2920);
// EXTERNAL MODULE: ./context/book/reducer.js
var book_reducer = __webpack_require__(4682);
// EXTERNAL MODULE: ./context/facility/reducer.js
var facility_reducer = __webpack_require__(2928);
// EXTERNAL MODULE: ./context/breakfast/reducer.js
var breakfast_reducer = __webpack_require__(9744);
// EXTERNAL MODULE: ./context/meal/reducer.js
var meal_reducer = __webpack_require__(8881);
// EXTERNAL MODULE: ./context/bedType/reducer.js
var bedType_reducer = __webpack_require__(3951);
// EXTERNAL MODULE: ./context/currency/reducer.js
var currency_reducer = __webpack_require__(9968);
// EXTERNAL MODULE: ./context/mappingHotel/reducer.js
var mappingHotel_reducer = __webpack_require__(3477);
;// CONCATENATED MODULE: ./context/index.js



















function CombinedContextProvider({ children  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(cityLocation_reducer/* CityLocationContextProvider */.Y, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(nationality_reducer/* NationalityContextProvider */.j, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(country_reducer/* CountryContextProvider */.I, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(reducer/* AuthContextProvider */.H, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(city_reducer/* CityContextProvider */.r, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(book_reducer/* BookContextProvider */.v, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(hotel_reducer/* HotelContextProvider */.J, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(facility_reducer/* FacilityContextProvider */.b, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(breakfast_reducer/* BreakfastContextProvider */.k, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(meal_reducer/* MealContextProvider */.D, {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(operatorMan_reducer/* OperatorManContextProvider */.s, {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(salesOffice_reducer/* SalesOfficeContextProvider */.v, {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(currency_reducer/* CurrencyContextProvider */.S, {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(supplier_reducer/* SupplierContextProvider */.o, {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(mappingCountry_reducer/* MappingCountryContextProvider */._, {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(mappingCity_reducer/* MappingCityContextProvider */.r, {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(mappingHotel_reducer/* MappingHotelContextProvider */.m, {
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(bedType_reducer/* BedTypeContextProvider */.J, {
                                                                            children: children
                                                                        })
                                                                    })
                                                                })
                                                            })
                                                        })
                                                    })
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    });
}

// EXTERNAL MODULE: ./node_modules/bootstrap/dist/css/bootstrap.css
var bootstrap = __webpack_require__(5931);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: ./node_modules/react-calendar/dist/Calendar.css
var Calendar = __webpack_require__(8434);
// EXTERNAL MODULE: ./node_modules/leaflet/dist/leaflet.css
var leaflet = __webpack_require__(9637);
// EXTERNAL MODULE: ./node_modules/leaflet-geosearch/dist/geosearch.css
var geosearch = __webpack_require__(5467);
// EXTERNAL MODULE: ./node_modules/react-datetime/css/react-datetime.css
var react_datetime = __webpack_require__(1600);
;// CONCATENATED MODULE: ./pages/_app.js









function MyApp({ Component , pageProps  }) {
    (0,external_react_.useEffect)(()=>{
        Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 7064, 23));
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(CombinedContextProvider, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 5931:
/***/ (() => {



/***/ }),

/***/ 5467:
/***/ (() => {



/***/ }),

/***/ 9637:
/***/ (() => {



/***/ }),

/***/ 8434:
/***/ (() => {



/***/ }),

/***/ 1600:
/***/ (() => {



/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 7064:
/***/ ((module) => {

"use strict";
module.exports = require("bootstrap/dist/js/bootstrap");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [6552,3363,8796,1906,1118,9968,6821,2920,4682,5159,3240,7324,3306,2413,3477,9744,2928,8881,3951], () => (__webpack_exec__(3195)));
module.exports = __webpack_exports__;

})();