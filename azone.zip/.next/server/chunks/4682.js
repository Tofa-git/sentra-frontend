"use strict";
exports.id = 4682;
exports.ids = [4682];
exports.modules = {

/***/ 4682:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ BookContext),
/* harmony export */   "v": () => (/* binding */ BookContextProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);



const BookContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
const initialState = {
    isLoading: false,
    isError: false,
    errorMessage: null,
    dataSearch: [],
    dataList: [],
    details: null
};
function reducer(state, action) {
    switch(action.type){
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_SEARCH_PROCESS */ .bk:
            return {
                ...state,
                isLoading: true
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_SEARCH_SUCCESS */ .Rb:
            return {
                ...state,
                isLoading: false,
                data: action.payload.data
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_SEARCH_FAILED */ .ad:
            return {
                ...state,
                isLoading: false,
                isError: true,
                errorMessage: action.payload
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_LIST_PROCESS */ .pj:
            return {
                ...state,
                isLoading: true
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_LIST_SUCCESS */ .v:
            return {
                ...state,
                isLoading: false,
                dataList: action.payload.data
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_LIST_FAILED */ .sf:
            return {
                ...state,
                isLoading: false,
                isError: true,
                errorMessage: action.payload
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_DETAIL_PROCESS */ .S7:
            return {
                ...state,
                isLoading: true
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_DETAIL_SUCCESS */ .Yk:
            return {
                ...state,
                isLoading: false,
                details: action.payload.data
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_DETAIL_FAILED */ .sd:
            return {
                ...state,
                isLoading: false,
                isError: true,
                errorMessage: action.payload
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_SEARCH_RESET */ .MH:
            return {
                ...initialState
            };
        default:
            return state;
    }
}
function BookContextProvider({ children  }) {
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, initialState);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BookContext.Provider, {
        value: {
            state,
            dispatch
        },
        children: children
    });
}



/***/ })

};
;