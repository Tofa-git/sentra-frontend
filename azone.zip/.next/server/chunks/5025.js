"use strict";
exports.id = 5025;
exports.ids = [5025];
exports.modules = {

/***/ 5025:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VA": () => (/* binding */ updateData),
/* harmony export */   "Yu": () => (/* binding */ getData),
/* harmony export */   "ZT": () => (/* binding */ getDDLCountry),
/* harmony export */   "hL": () => (/* binding */ syncData)
/* harmony export */ });
/* unused harmony export createData */
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const getData = async (dispatch, isSync = false, page = 1, limit = 12, supplierId, name = "")=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_COUNTRY_PROCESS */ .G0
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/show-mapcountry?page=${page}&limit=${limit}`;
        let method = "GET";
        let body = null;
        if (name.length > 0) {
            url += `&name=${name}`;
        }
        if (isSync) {
            url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/show-mapcountry?page=${page}&limit=${limit}`;
        } else {
            // Set the method to POST for synchronization
            method = "POST";
            body = JSON.stringify({
                supplierId: supplierId ?? 0
            });
        }
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: method,
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json"
            },
            body: body
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_COUNTRY_SUCCESS */ .qJ,
            payload: {
                data: data?.data,
                isSync
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_COUNTRY_FAILED */ .o_,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
const syncData = async (dispatch, isSync = true, supplierId = 0)=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_COUNTRY_PROCESS */ .G0
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/sync-mapcountry/${supplierId}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_COUNTRY_SUCCESS */ .qJ,
            payload: {
                data: data?.data,
                isSync
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_COUNTRY_FAILED */ .o_,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
const createData = async (body)=>{
    try {
        const url = `${baseUrl}/api/integration/create-mapcountry`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Create Success", "Data has been successfully created", "success");
    } catch (error) {
        Swal.fire("Create Failed", "Error when create data, please try again later", "error");
    }
};
const updateData = async (id, body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/update-mapcountry/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"].put(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Update Success", "Data has been successfully updated", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Update Failed", "Error when update data, please try again later", "error");
    }
};
const getDDLCountry = async (dispatch, supplierid, isDropDown = true)=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_COUNTRY_PROCESS */ .G0
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/mapcountry-dd?supplierId=${supplierid}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "POST",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        console.log(data);
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_COUNTRY_SUCCESS */ .qJ,
            payload: {
                data: data?.data,
                isDropDown
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        console.log(error);
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_COUNTRY_FAILED */ .o_,
            payload: error?.response?.data?.message || "Error"
        });
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;