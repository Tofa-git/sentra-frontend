"use strict";
exports.id = 6332;
exports.ids = [6332];
exports.modules = {

/***/ 1062:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo.4c365648.png","height":565,"width":1591,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAWElEQVR4nBWMsQmAQBRDXxZQsBUcwLMV3Mc5nEfsbRzAeZTrBDH+65K8R7QuQwJG5B3TRm4sZXAlKxdhjjIhbdhnCF0IX2wW3CGkHlQeDqNLpg6igK/h+QHRch9HelFw9AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 2322:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Layout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_auth_reducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1118);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _context_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6552);
//import component Navbar





function Layout({ children  }) {
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_context_auth_reducer__WEBPACK_IMPORTED_MODULE_2__/* .AuthContext */ .V);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const token = localStorage.getItem("AUTH_TOKEN");
        if (token) {
            dispatch({
                type: _context_constant__WEBPACK_IMPORTED_MODULE_4__/* .AUTH_SUCCESS */ .DP
            });
        }
        if (!state.isAuthenticated && !token) {
            router.push("/authentication/login");
        }
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
            className: "d-flex justify-content-center align-items-center bg-primary",
            style: {
                height: "100vh"
            },
            children: children
        })
    });
}


/***/ })

};
;