"use strict";
exports.id = 50;
exports.ids = [50];
exports.modules = {

/***/ 50:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$U": () => (/* binding */ getAllCityLocation),
/* harmony export */   "bE": () => (/* binding */ deleteCityLocation),
/* harmony export */   "i1": () => (/* binding */ createCityLocation),
/* harmony export */   "zX": () => (/* binding */ updateCityLocation)
/* harmony export */ });
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const getAllCityLocation = async (dispatch, isDropDown = false, page = 1, limit = 12, name = "")=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .CITY_LOCATION_PROCESS */ .Db
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/city-location?page=${page}&limit=${limit}`;
        if (name.length > 0) {
            url += `&name=${name}`;
        }
        if (isDropDown) {
            url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/city-location-dd`;
        }
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .CITY_LOCATION_SUCCESS */ .Pu,
            payload: {
                data: data?.data,
                isDropDown
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .CITY_LOCATION_FAILED */ .pB,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
const createCityLocation = async (body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/city-location`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Create Success", "CityLocation has been successfully created", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Create Failed", "Error when create cityLocation, please try again later", "error");
    }
};
const updateCityLocation = async (id, body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/city-location/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"].put(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Update Success", "CityLocation has been successfully updated", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Update Failed", "Error when update cityLocation, please try again later", "error");
    }
};
const deleteCityLocation = async (id)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/city-location/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"]["delete"](url, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Delete Success", "CityLocation has been successfully deleted", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Delete Failed", "Error when delete cityLocation, please try again later", "error");
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;