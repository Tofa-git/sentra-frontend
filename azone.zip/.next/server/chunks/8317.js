"use strict";
exports.id = 8317;
exports.ids = [8317];
exports.modules = {

/***/ 8317:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D2": () => (/* binding */ getDDLSupp),
/* harmony export */   "QU": () => (/* binding */ updateSuppEndPoint),
/* harmony export */   "XG": () => (/* binding */ createSuppEndPoint),
/* harmony export */   "eT": () => (/* binding */ deleteSupplier),
/* harmony export */   "tS": () => (/* binding */ getAllSupplier)
/* harmony export */ });
/* unused harmony exports createSupplier, updateSupplier, createSuppEmerg, updateSuppEmerg, deleteSuppEmerg, deleteSuppEndPoint, createSuppMan, updateSuppMan, deleteSuppMan */
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const getAllSupplier = async (dispatch, isDropDown = false, page = 1, limit = 12, name = "")=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .SUPPLIER_PROCESS */ .B6
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/suppliers?page=${page}&limit=${limit}`;
        if (name.length > 0) {
            url += `&name=${name}`;
        }
        if (isDropDown) {
            url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/supplier-dd`;
        }
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .SUPPLIER_SUCCESS */ .zX,
            payload: {
                data: data?.data,
                isDropDown
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .SUPPLIER_FAILED */ .h3,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
const createSupplier = async (body)=>{
    try {
        const url = `${baseUrl}/api/supplier`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Create Success", "Supplier has been successfully created", "success");
    } catch (error) {
        Swal.fire("Create Failed", "Error when create Supplier, please try again later", "error");
    }
};
const updateSupplier = async (id, body)=>{
    try {
        const url = `${baseUrl}/api/supplier/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.put(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Update Success", "Supplier has been successfully updated", "success");
    } catch (error) {
        Swal.fire("Update Failed", "Error when update Supplier, please try again later", "error");
    }
};
const deleteSupplier = async (id)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/supplier/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"]["delete"](url, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Delete Success", "Supplier has been successfully deleted", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Delete Failed", "Error when delete Supplier, please try again later", "error");
    }
};
const getDDLSupp = async (dispatch, isDropDown = true)=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .SUPPLIER_PROCESS */ .B6
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/supplier-dd`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .SUPPLIER_SUCCESS */ .zX,
            payload: {
                data: data?.data,
                isDropDown
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .SUPPLIER_FAILED */ .h3,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
/* Supplier Emergency */ const createSuppEmerg = async (body)=>{
    try {
        const url = `${baseUrl}/api/supplier/emergency`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Create Success", "Supplier Emergency has been successfully created", "success");
    } catch (error) {
        Swal.fire("Create Failed", "Error when create Supplier Emergency, please try again later", "error");
    }
};
const updateSuppEmerg = async (id, body)=>{
    try {
        const url = `${baseUrl}/api/supplier/emergency/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.put(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Update Success", "Supplier Emergency has been successfully updated", "success");
    } catch (error) {
        Swal.fire("Update Failed", "Error when update Supplier Emergency, please try again later", "error");
    }
};
const deleteSuppEmerg = async (id)=>{
    try {
        const url = `${baseUrl}/api/supplier/emergency/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.delete(url, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Delete Success", "Supplier Emergency has been successfully deleted", "success");
    } catch (error) {
        Swal.fire("Delete Failed", "Error when delete Supplier Emergency, please try again later", "error");
    }
};
/* Supplier EndPoint */ const createSuppEndPoint = async (body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/supplier/api`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Create Success", "End Point has been successfully created", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Create Failed", "Error when create End Point, please try again later", "error");
    }
};
const updateSuppEndPoint = async (id, body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/supplier/api/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"].put(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Update Success", "End Point has been successfully updated", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Update Failed", "Error when update End Point, please try again later", "error");
    }
};
const deleteSuppEndPoint = async (id)=>{
    try {
        const url = `${baseUrl}/api/supplier/api/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.delete(url, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Delete Success", "End Point has been successfully deleted", "success");
    } catch (error) {
        Swal.fire("Delete Failed", "Error when delete End Point, please try again later", "error");
    }
};
/* Supplier Manager */ const createSuppMan = async (body)=>{
    try {
        const url = `${baseUrl}/api/supplier/manager`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Create Success", "Supplier Manager has been successfully created", "success");
    } catch (error) {
        Swal.fire("Create Failed", "Error when create Supplier Manager, please try again later", "error");
    }
};
const updateSuppMan = async (id, body)=>{
    try {
        const url = `${baseUrl}/api/supplier/manager/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.put(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Update Success", "Supplier Manager has been successfully updated", "success");
    } catch (error) {
        Swal.fire("Update Failed", "Error when update Supplier Manager, please try again later", "error");
    }
};
const deleteSuppMan = async (id)=>{
    try {
        const url = `${baseUrl}/api/supplier/manager/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.delete(url, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Delete Success", "Supplier Manager has been successfully deleted", "success");
    } catch (error) {
        Swal.fire("Delete Failed", "Error when delete Supplier Manager, please try again later", "error");
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;