"use strict";
exports.id = 9968;
exports.ids = [9968];
exports.modules = {

/***/ 9968:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ CurrencyContext),
/* harmony export */   "S": () => (/* binding */ CurrencyContextProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);



const CurrencyContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
const initialState = {
    isLoading: false,
    isError: false,
    errorMessage: null,
    data: {
        rows: [],
        limit: 2,
        page: 1,
        totalPage: 0,
        hasNext: false,
        hasPreviouse: false
    },
    dropdownData: []
};
function reducer(state, action) {
    switch(action.type){
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .CURRENCY_PROCESS */ .vw:
            return {
                ...state,
                isLoading: true
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .CURRENCY_SUCCESS */ .Ur:
            const changedState = {
                isLoading: false,
                isError: false,
                errorMessage: null
            };
            if (action.payload.isDropDown) {
                return {
                    ...state,
                    ...changedState,
                    dropdownData: action.payload.data
                };
            } else {
                return {
                    ...state,
                    ...changedState,
                    data: action.payload.data
                };
            }
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .CURRENCY_FAILED */ .Am:
            return {
                ...state,
                isLoading: false,
                isError: true,
                errorMessage: action.payload
            };
        default:
            return state;
    }
}
function CurrencyContextProvider({ children  }) {
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, initialState);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CurrencyContext.Provider, {
        value: {
            state,
            dispatch
        },
        children: children
    });
}



/***/ })

};
;