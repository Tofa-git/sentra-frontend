"use strict";
exports.id = 3323;
exports.ids = [3323];
exports.modules = {

/***/ 3323:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DE": () => (/* binding */ getCurrencies),
/* harmony export */   "J$": () => (/* binding */ createCountry),
/* harmony export */   "fc": () => (/* binding */ updateCountry),
/* harmony export */   "g_": () => (/* binding */ getAllCountry),
/* harmony export */   "wy": () => (/* binding */ deleteCountry)
/* harmony export */ });
/* unused harmony export getSupplierCountry */
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const getAllCountry = async (dispatch, isDropDown = false, page = 1, limit = 12, name = "")=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .COUNTRY_PROCESS */ .Cf
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/country-code?page=${page}&limit=${limit}`;
        if (name.length > 0) {
            url += `&name=${name}`;
        }
        if (isDropDown) {
            url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/country-code-dd`;
        }
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .COUNTRY_SUCCESS */ .HA,
            payload: {
                data: data?.data,
                isDropDown
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .COUNTRY_FAILED */ .gW,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
const createCountry = async (body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/country-code`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Create Success", "Country has been successfully created", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Create Failed", "Error when create country, please try again later", "error");
    }
};
const updateCountry = async (id, body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/country-code/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"].put(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Update Success", "Country has been successfully updated", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Update Failed", "Error when update country, please try again later", "error");
    }
};
const deleteCountry = async (id)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/country-code/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"]["delete"](url, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Delete Success", "Country has been successfully deleted", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Delete Failed", "Error when delete country, please try again later", "error");
    }
};
const getCurrencies = async (dispatch)=>{
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/currencies`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .CURRENCIES_SUCCESS */ .s9,
            payload: {
                data: data?.data
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .CURRENCIES_FAILED */ .xY,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
const getSupplierCountry = async (dispatch, isDropDown = false, page = 1, limit = 12, name = "")=>{};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;