"use strict";
exports.id = 7717;
exports.ids = [7717];
exports.modules = {

/***/ 7717:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ login),
/* harmony export */   "x": () => (/* binding */ getAllUserDD)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const getAllUserDD = async (dispatch)=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .GET_USER_PROCESS */ .KT
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/users-dd`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .GET_USER_SUCCESS */ .VV,
            payload: {
                data: data?.data
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .GET_USER_FAILED */ .P0,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
const login = async (dispatch, email, password)=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .AUTH_PROCESS */ .L3
    });
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/login`;
        const config = {
            method: "post",
            url,
            data: {
                email: email,
                password: password
            },
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json"
            }
        };
        const res = await (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])(config);
        const data = res.data;
        localStorage.setItem("AUTH_TOKEN", data.data.token);
        sweetalert2__WEBPACK_IMPORTED_MODULE_1___default().fire("Successfully Login", "", "success");
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .AUTH_SUCCESS */ .DP,
            payload: data.data
        });
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_1___default().fire("Failed", error?.response?.data?.message, "error");
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .AUTH_FAILED */ .v$,
            payload: error?.response?.data?.message || "Error"
        });
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;