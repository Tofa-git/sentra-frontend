"use strict";
exports.id = 1655;
exports.ids = [1655];
exports.modules = {

/***/ 1655:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_input__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7267);
/* harmony import */ var _components_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2857);
/* harmony import */ var _context_city_reducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8796);
/* harmony import */ var _context_cityLocation_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4882);
/* harmony import */ var _context_currency_reducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9968);
/* harmony import */ var _context_country_reducer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3363);
/* harmony import */ var _context_hotel_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(487);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_hotel_actions__WEBPACK_IMPORTED_MODULE_8__]);
_context_hotel_actions__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










// const Map = dynamic(() => import("../../components/map/index"), { ssr: false });
const initForm = {
    code: "",
    category: "",
    name: "",
    email: "",
    phone: "",
    fax: "",
    rqEmail: "",
    ccEmail: "",
    address: "",
    url: "",
    urlApi: "",
    address: "",
    remark: "",
    creditDay: "",
    currency: "",
    exchangeRate: "",
    agentMarkup: "false",
    xmlMapping: "false",
    status: "1",
    fileIds: []
};
const statusData = [
    {
        id: "1",
        name: "Yes"
    },
    {
        id: "0",
        name: "No"
    }
];
const categoryData = [
    {
        id: "Overseas Supplier",
        name: "Overseas Supplier"
    },
    {
        id: "Local Supplier",
        name: "Local Supplier"
    }
];
const CreateForm = (props)=>{
    const { isEdit , selectedData  } = props;
    const [form, setForm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initForm);
    const { state: countryState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country_reducer__WEBPACK_IMPORTED_MODULE_7__/* .CountryContext */ .o);
    const { state: cityState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_city_reducer__WEBPACK_IMPORTED_MODULE_4__/* .CityContext */ .i);
    const { state: cityLocationState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_cityLocation_reducer__WEBPACK_IMPORTED_MODULE_5__/* .CityLocationContext */ .O);
    const { state: currencyState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_currency_reducer__WEBPACK_IMPORTED_MODULE_6__/* .CurrencyContext */ .$);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        console.log(selectedData);
        setForm(isEdit ? selectedData : initForm);
    }, [
        selectedData,
        isEdit
    ]);
    const handleInputChange = (name, value)=>{
        setForm({
            ...form,
            [name]: value
        });
    };
    const handleSubmit = async ()=>{
        const requiredField = [
            "code",
            "name",
            "address",
            "phone",
            "email",
            "status"
        ];
        const hasError = requiredField.filter((i)=>form[i] === 0 || form[i]?.length === 0);
        if (hasError.length > 0) {
            return sweetalert2__WEBPACK_IMPORTED_MODULE_9___default().fire("Validate", `Field ${hasError.join(", ").toLocaleUpperCase()} can't empty or 0`, "warning");
        }
        if (isEdit) {
            await (0,_context_hotel_actions__WEBPACK_IMPORTED_MODULE_8__/* .updateHotel */ .cB)(selectedData.id, form);
        } else {
            await (0,_context_hotel_actions__WEBPACK_IMPORTED_MODULE_8__/* .createHotel */ .dZ)(form);
        }
        await props.handleGet();
        document.getElementById("cancelModal").click();
    };
    const handleCancel = ()=>{
        setForm(initForm);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "modal fade",
        id: props.id,
        tabIndex: "-1",
        "aria-labelledby": "exampleModalLabel",
        "aria-hidden": "true",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: props.size + " modal-dialog",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "modal-content rounded-2 shadow",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-header",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                className: "modal-title fs-5 text-black",
                                id: props.id + "Label",
                                children: [
                                    isEdit ? "Edit" : "Add",
                                    " Supplier Information"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn-close",
                                "data-bs-dismiss": "modal",
                                "aria-label": "Close",
                                onClick: ()=>handleCancel()
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-body p-3",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row mt-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Code",
                                        value: form.code,
                                        onChange: (val)=>handleInputChange("code", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        label: "Category",
                                        options: categoryData,
                                        value: form.category,
                                        onChange: (val)=>handleInputChange("category", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Name",
                                        value: form.name,
                                        onChange: (val)=>handleInputChange("name", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Email",
                                        value: form.email,
                                        onChange: (val)=>handleInputChange("email", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Phone",
                                        value: form.phone,
                                        onChange: (val)=>handleInputChange("phone", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Fax",
                                        value: form.fax,
                                        onChange: (val)=>handleInputChange("fax", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "RQ Email",
                                        value: form.rqEmail,
                                        onChange: (val)=>handleInputChange("rqEmail", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "CC Email",
                                        value: form.ccEmail,
                                        onChange: (val)=>handleInputChange("ccEmail", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Address",
                                        value: form.address,
                                        onChange: (val)=>handleInputChange("address", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Url",
                                        value: form.url,
                                        onChange: (val)=>handleInputChange("url", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Url Api",
                                        value: form.urlApi,
                                        onChange: (val)=>handleInputChange("urlApi", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Remark",
                                        value: form.remark,
                                        onChange: (val)=>handleInputChange("remark", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Credit Day",
                                        value: form.creditDay,
                                        onChange: (val)=>handleInputChange("creditDay", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        label: "Currency",
                                        value: form.currency,
                                        options: currencyState?.dropdownData,
                                        onChange: (val)=>handleInputChange("currency", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Exchange Rate",
                                        value: form.exchangeRate,
                                        onChange: (val)=>handleInputChange("exchangeRate", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        type: "checkbox",
                                        label: "Skip Agent Markup"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        type: "checkbox",
                                        label: "Access For XML Mapping"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        label: "Used",
                                        options: statusData,
                                        value: form.status,
                                        onChange: (val)=>handleInputChange("status", val.target.value)
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-footer",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn btn-danger rounded-0",
                                "data-bs-dismiss": "modal",
                                id: "cancelModal",
                                onClick: ()=>handleCancel(),
                                children: "Cancel"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>{
                                    handleSubmit();
                                },
                                type: "button",
                                className: "btn btn-primary rounded-0",
                                children: isEdit ? "Edit" : "Add"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;