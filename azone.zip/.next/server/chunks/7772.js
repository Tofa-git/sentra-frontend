"use strict";
exports.id = 7772;
exports.ids = [7772];
exports.modules = {

/***/ 4263:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5666);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_0__);

const secretKey = "s3ntRa-h0t3L";
const encryptData = (data)=>{
    const encryptedPhone = crypto_js__WEBPACK_IMPORTED_MODULE_0__.AES.encrypt(data, secretKey).toString();
    return encryptedPhone;
};
const decryptData = (encryptedData)=>{
    const bytes = crypto_js__WEBPACK_IMPORTED_MODULE_0__.AES.decrypt(encryptedData, secretKey);
    const decryptedData = bytes.toString(crypto_js__WEBPACK_IMPORTED_MODULE_0__.enc.Utf8);
    return decryptedData;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    encryptData,
    decryptData
});


/***/ }),

/***/ 7772:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_input__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7267);
/* harmony import */ var _components_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2857);
/* harmony import */ var _components_encrypt_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4263);
/* harmony import */ var _context_supplier_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8317);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _context_supplier_reducer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2920);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_supplier_actions__WEBPACK_IMPORTED_MODULE_5__]);
_context_supplier_actions__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const initForm = {
    id: "",
    supplierId: "",
    name: "",
    endpoint: "",
    method: "",
    code: "",
    user: "",
    url: "",
    password: "",
    body: "",
    status: 1
};
const namesData = [
    {
        id: "City",
        name: "City"
    },
    {
        id: "Country",
        name: "Country"
    },
    {
        id: "Hotel",
        name: "Hotel"
    },
    {
        id: "Bed",
        name: "Bed Type"
    },
    {
        id: "Meal",
        name: "Meal Type"
    },
    {
        id: "Search",
        name: "Search"
    },
    {
        id: "Confirm",
        name: "Confirm"
    },
    {
        id: "Book",
        name: "Book"
    },
    {
        id: "Search Room",
        name: "Search Room"
    }
];
const methodData = [
    {
        id: "GET",
        name: "Get"
    },
    {
        id: "POST",
        name: "Post"
    },
    {
        id: "PUT",
        name: "Put"
    },
    {
        id: "DELETE",
        name: "Delete"
    }
];
const statusData = [
    {
        id: "1",
        name: "Yes"
    },
    {
        id: "0",
        name: "No"
    }
];
const SchemaForm = (props)=>{
    const { isEdit , selectedData  } = props;
    const [form, setForm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initForm);
    const [schemaText, setSchemaText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [savedSchema, setSavedSchema] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { state: supplierDDLState , dispatch: supplierDDLDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_supplier_reducer__WEBPACK_IMPORTED_MODULE_7__/* .SupplierContext */ .e);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        handleDropDown();
        setForm(isEdit ? selectedData : initForm);
        if (isEdit) {
            setForm((prevForm)=>({
                    ...prevForm,
                    endpoint: selectedData.endpoint == null ? "" : _components_encrypt_index__WEBPACK_IMPORTED_MODULE_4__/* ["default"].decryptData */ .Z.decryptData(selectedData.endpoint),
                    body: selectedData.body == null ? "" : _components_encrypt_index__WEBPACK_IMPORTED_MODULE_4__/* ["default"].decryptData */ .Z.decryptData(selectedData.body),
                    user: selectedData.user == null ? "" : _components_encrypt_index__WEBPACK_IMPORTED_MODULE_4__/* ["default"].decryptData */ .Z.decryptData(selectedData.user),
                    password: selectedData.password == null ? "" : _components_encrypt_index__WEBPACK_IMPORTED_MODULE_4__/* ["default"].decryptData */ .Z.decryptData(selectedData.password),
                    code: selectedData.code == null ? "" : _components_encrypt_index__WEBPACK_IMPORTED_MODULE_4__/* ["default"].decryptData */ .Z.decryptData(selectedData.code ?? ""),
                    url: selectedData.url == null ? "" : _components_encrypt_index__WEBPACK_IMPORTED_MODULE_4__/* ["default"].decryptData */ .Z.decryptData(selectedData.url ?? "")
                }));
        // console.log(CryptoUtils.decryptData(selectedData.url))
        }
    }, [
        selectedData,
        isEdit
    ]);
    const handleSchemaChange = (event)=>{
        setSchemaText(event.target.value);
    };
    const handleInputChange = (name, value)=>{
        setForm({
            ...form,
            [name]: value
        });
    };
    const handleDropDown = async ()=>{
        const ddl = await (0,_context_supplier_actions__WEBPACK_IMPORTED_MODULE_5__/* .getDDLSupp */ .D2)(supplierDDLDispatch, true);
        if (ddl.status === 401) {
            authDispatch({
                type: AUTH_401
            });
            authDispatch({
                type: AUTH_LOGOUT
            });
            sweetalert2__WEBPACK_IMPORTED_MODULE_6___default().fire("Token has been Expired", "Please Login Again", "warning");
            router.push("/authentication/login");
        }
    };
    const handleSubmit = async ()=>{
        const requiredField = [
            "supplierId",
            "name",
            "endpoint",
            "method",
            "user",
            "password",
            "body"
        ];
        const hasError = requiredField.filter((i)=>form[i] === 0 || form[i]?.length === 0);
        if (hasError.length > 0) {
            return sweetalert2__WEBPACK_IMPORTED_MODULE_6___default().fire("Validate", `Field ${hasError.join(", ").toLocaleUpperCase()} can't empty or 0`, "warning");
        }
        if (isEdit) {
            console.log(form);
            await (0,_context_supplier_actions__WEBPACK_IMPORTED_MODULE_5__/* .updateSuppEndPoint */ .QU)(selectedData.id, form);
        } else {
            await (0,_context_supplier_actions__WEBPACK_IMPORTED_MODULE_5__/* .createSuppEndPoint */ .XG)(form);
        }
    };
    const handleCancel = ()=>{
        setForm(initForm);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "modal fade",
        id: props.id,
        tabIndex: "-1",
        "aria-labelledby": "exampleModalLabel",
        "aria-hidden": "true",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: props.size + " modal-dialog",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "modal-content rounded-2 shadow",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-header",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                className: "modal-title fs-5 text-black",
                                id: props.id + "Label",
                                children: [
                                    isEdit ? "Edit" : "Add",
                                    " Supplier EndPoint Management"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn-close",
                                "data-bs-dismiss": "modal",
                                "aria-label": "Close",
                                onClick: ()=>handleCancel()
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "modal-body p-3",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row mt-2",
                            children: [
                                isEdit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        options: supplierDDLState?.dropdownData,
                                        label: "Supplier",
                                        value: form.supplierId,
                                        onChange: (val)=>handleInputChange("supplierId", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        options: namesData,
                                        label: "Name",
                                        value: form.name,
                                        onChange: (val)=>handleInputChange("name", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        options: methodData,
                                        label: "Method",
                                        value: form.method,
                                        onChange: (val)=>handleInputChange("method", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Endpoint Url (Leave it blank if the url is same as api url)",
                                        value: form.url,
                                        onChange: (val)=>handleInputChange("url", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Endpoint",
                                        value: form.endpoint,
                                        onChange: (val)=>handleInputChange("endpoint", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "User",
                                        value: form.user,
                                        onChange: (val)=>handleInputChange("user", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Password",
                                        value: form.password,
                                        onChange: (val)=>handleInputChange("password", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        label: "Code",
                                        value: form.code,
                                        onChange: (val)=>handleInputChange("code", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        label: "Is Used",
                                        value: form.status,
                                        options: statusData,
                                        onChange: (val)=>handleInputChange("status", val.target.value)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "mt-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: `form-label`,
                                                children: "Body"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "input-group-sm",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                    rows: "10",
                                                    className: "w-100",
                                                    value: form.body,
                                                    onChange: (val)=>handleInputChange("body", val.target.value),
                                                    placeholder: "Input the body of the API, need to put bracket or array if exist `[]` / `{}`"
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-footer",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn btn-danger rounded-0",
                                "data-bs-dismiss": "modal",
                                id: "cancelModal",
                                onClick: ()=>handleCancel(),
                                children: "Cancel"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>{
                                    handleSubmit();
                                },
                                type: "button",
                                className: "btn btn-primary rounded-0",
                                children: isEdit ? "Edit" : "Add"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SchemaForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;