"use strict";
exports.id = 7267;
exports.ids = [7267];
exports.modules = {

/***/ 7267:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Input)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_datetime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(611);
/* harmony import */ var react_datetime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_datetime__WEBPACK_IMPORTED_MODULE_2__);



function Input({ type ="text" , label ="" , isInvalid =false , required =true , errors =[] , bgColor ="text-light" , onChange =()=>{} , value =null , multiple =false , disabled =false  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "mt-2",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `form-label ${label !== "" ? "text-dark" : bgColor}`,
                children: label !== "" ? label : "-"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "input-group-sm",
                children: type === "date" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_datetime__WEBPACK_IMPORTED_MODULE_2___default()), {
                    dateFormat: "YYYY-MM-DD",
                    timeFormat: false,
                    onChange: (val)=>onChange(val.format("YYYY-MM-DD")),
                    value: value,
                    disabled: disabled
                }) : type === "checkbox" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "checkbox",
                    className: `form-check-input ${isInvalid ? "is-invalid" : ""}`,
                    required: required,
                    onChange: onChange,
                    checked: value,
                    disabled: disabled
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: type,
                    className: `form-control ${isInvalid ? "is-invalid" : ""}`,
                    required: required,
                    onChange: onChange,
                    value: value,
                    multiple: multiple,
                    disabled: disabled
                })
            }),
            errors.map((v, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "form-text text-danger",
                    children: v
                }, i))
        ]
    });
}


/***/ })

};
;