"use strict";
exports.id = 1998;
exports.ids = [1998];
exports.modules = {

/***/ 1998:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7267);
/* harmony import */ var _components_select__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2857);
/* harmony import */ var _createSupListForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1655);
/* harmony import */ var _createSupManForm__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5752);
/* harmony import */ var _createSupEmergForm__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1799);
/* harmony import */ var _createSupEndpointForm__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7772);
/* harmony import */ var _context_auth_reducer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1118);
/* harmony import */ var _context_supplier_reducer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2920);
/* harmony import */ var _context_supplier_actions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8317);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_createSupListForm__WEBPACK_IMPORTED_MODULE_5__, _createSupManForm__WEBPACK_IMPORTED_MODULE_6__, _createSupEmergForm__WEBPACK_IMPORTED_MODULE_7__, _createSupEndpointForm__WEBPACK_IMPORTED_MODULE_8__, _context_supplier_actions__WEBPACK_IMPORTED_MODULE_11__]);
([_createSupListForm__WEBPACK_IMPORTED_MODULE_5__, _createSupManForm__WEBPACK_IMPORTED_MODULE_6__, _createSupEmergForm__WEBPACK_IMPORTED_MODULE_7__, _createSupEndpointForm__WEBPACK_IMPORTED_MODULE_8__, _context_supplier_actions__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const dummyData = [
    {
        id: 1,
        location_code: "ALOR",
        location_name_en: "Alor",
        location_name_ch: "4",
        is_used: 1
    },
    {
        id: 2,
        location_code: "AMBA",
        location_name_en: "Ambarawa",
        location_name_ch: "3",
        is_used: 1
    },
    {
        id: 3,
        location_code: "AMQ",
        location_name_en: "Ambon",
        location_name_ch: "5",
        is_used: 0
    }
];
const Index = (props)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const [selectedData, setSelectedData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [isEdit, setIsEdit] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isOpenManager, setOpenmanager] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isOpenEmergency, setOpenemergency] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [keyword, setKeyword] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_supplier_reducer__WEBPACK_IMPORTED_MODULE_10__/* .SupplierContext */ .e);
    const { dispatch: authDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_reducer__WEBPACK_IMPORTED_MODULE_9__/* .AuthContext */ .V);
    const [numDivs, setNumDivs] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [markupEndValues, setMarkupEndValues] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        "0"
    ]);
    const handleMarkupEnd1Change = (e)=>{
        const newValue = e.target.value;
        setMarkupEndValues([
            newValue
        ]); // Update the state with a new array containing only the entered value
        setNumDivs(2); // Reset numDivs to 1 when a new value is entered in markup_end1
    };
    const handleMarkupEndInputChange = (index, value)=>{
        const updatedValues = [
            ...markupEndValues
        ];
        updatedValues[index] = value;
        setMarkupEndValues(updatedValues);
        setNumDivs(index + 3);
    };
    // State to store the index of the selected row
    const [selectedRowIndex, setSelectedRowIndex] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const handleRowClick = (index)=>{
        setOpenmanager(true);
        setSelectedRowIndex((prevIndex)=>prevIndex === index ? null : index);
    };
    const [selectedRowManIndex, setSelectedRowManIndex] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const handleRowMan = (index)=>{
        setOpenemergency(true);
        setSelectedRowManIndex((prevIndex)=>prevIndex === index ? null : index);
    };
    const handleGet = async (page = 1, limit = 12)=>{
        const supplier = await (0,_context_supplier_actions__WEBPACK_IMPORTED_MODULE_11__/* .getAllSupplier */ .tS)(dispatch, false, page, limit, keyword);
        if (supplier.status === 401) {
            authDispatch({
                type: AUTH_401
            });
            authDispatch({
                type: AUTH_LOGOUT
            });
            Swal.fire("Token has been Expired", "Please Login Again", "warning");
            router.push("/authentication/login");
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        handleGet();
    }, []);
    const deleteSuppData = async (id)=>{
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then(async (result)=>{
            if (result.isConfirmed) {
                await (0,_context_supplier_actions__WEBPACK_IMPORTED_MODULE_11__/* .deleteSupplier */ .eT)(id);
                handleGet();
            }
        });
    };
    const toolbarSupList = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "d-flex flex-row align-items-center bg-light p-2",
            style: {
                borderBottom: "1px solid #dddddd"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex-shrink-1 pe-1 small text-nowrap text-dark",
                    children: "Sort By"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-fill input-group",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                        className: "form-select rounded-0",
                        name: "i_field",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "-",
                                children: "UID"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "-",
                                children: "Sales Office"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "-",
                                children: "Used"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                    children: "Used"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-fill input-group",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                        className: "form-select rounded-0",
                        name: "i_field",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "-",
                                children: "Yes"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "-",
                                children: "No"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                    children: "Code/Name"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex-fill input-group",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            name: "q",
                            type: "text",
                            className: "form-control bg-white rounded-0 p-0 px-1",
                            placeholder: "User ID/Name"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "d-flex input-group-append",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "d-flex btn-group",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "btn btn-outline-secondary rounded-0",
                                    id: "search_button",
                                    role: "button",
                                    title: "Go Search",
                                    style: {
                                        padding: "2px 5px"
                                    },
                                    href: "#",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "material-icons",
                                        style: {
                                            verticalAlign: "middle"
                                        },
                                        children: "search"
                                    })
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                    className: "btn btn-sm btn-primary bg-blue ms-2 rounded-0 d-flex flex-row align-items-center shadow-sm",
                    "data-bs-toggle": "modal",
                    "data-bs-target": "#createHotel",
                    onClick: ()=>setIsEdit(false),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            className: "material-icons fs-6",
                            style: {
                                verticalAlign: "middle"
                            },
                            children: "add"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "ms-2",
                            children: "Tambah"
                        })
                    ]
                })
            ]
        })
    });
    const toolbarSupEndpoint = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "d-flex flex-row align-items-center bg-light p-2",
            style: {
                borderBottom: "1px solid #dddddd"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                    children: "Used"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-fill input-group",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                        className: "form-select rounded-0",
                        name: "i_field",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "-",
                                children: "Yes"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "-",
                                children: "No"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                    children: "Supplier Name"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex-fill input-group",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            name: "q",
                            type: "text",
                            className: "form-control bg-white rounded-0 p-0 px-1",
                            placeholder: "Supplier Name"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "d-flex input-group-append",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "d-flex btn-group",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "btn btn-outline-secondary rounded-0",
                                    id: "search_button",
                                    role: "button",
                                    title: "Go Search",
                                    style: {
                                        padding: "2px 5px"
                                    },
                                    href: "#",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "material-icons",
                                        style: {
                                            verticalAlign: "middle"
                                        },
                                        children: "search"
                                    })
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                    className: "btn btn-sm btn-primary bg-blue ms-2 rounded-0 d-flex flex-row align-items-center shadow-sm",
                    "data-bs-toggle": "modal",
                    "data-bs-target": "#createSupEndpoint",
                    onClick: ()=>setIsEdit(false),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            className: "material-icons fs-6",
                            style: {
                                verticalAlign: "middle"
                            },
                            children: "add"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "ms-2",
                            children: "Tambah"
                        })
                    ]
                })
            ]
        })
    });
    const toolbarSupMan = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "d-flex flex-row align-items-center bg-light p-2",
            style: {
                borderBottom: "1px solid #dddddd"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex-shrink-1 pe-1 small text-nowrap text-dark",
                    children: "Sort By"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-fill input-group",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                        className: "form-select rounded-0",
                        name: "i_field",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "-",
                                children: "UID"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "-",
                                children: "Sales Office"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "-",
                                children: "Used"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                    children: "Used"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-fill input-group",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                        className: "form-select rounded-0",
                        name: "i_field",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "-",
                                children: "Yes"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "-",
                                children: "No"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                    children: "Code/Name"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex-fill input-group",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            name: "q",
                            type: "text",
                            className: "form-control bg-white rounded-0 p-0 px-1",
                            placeholder: "User ID/Name"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "d-flex input-group-append",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "d-flex btn-group",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "btn btn-outline-secondary rounded-0",
                                    id: "search_button",
                                    role: "button",
                                    title: "Go Search",
                                    style: {
                                        padding: "2px 5px"
                                    },
                                    href: "#",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "material-icons",
                                        style: {
                                            verticalAlign: "middle"
                                        },
                                        children: "search"
                                    })
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                    className: "btn btn-sm btn-primary bg-blue ms-2 rounded-0 d-flex flex-row align-items-center shadow-sm",
                    "data-bs-toggle": "modal",
                    "data-bs-target": "#createSupMan",
                    onClick: ()=>setIsEdit(false),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            className: "material-icons fs-6",
                            style: {
                                verticalAlign: "middle"
                            },
                            children: "add"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "ms-2",
                            children: "Tambah"
                        })
                    ]
                })
            ]
        })
    });
    const toolbarSupEmerg = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "d-flex flex-row align-items-center bg-light p-2",
            style: {
                borderBottom: "1px solid #dddddd"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                    children: "Used"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-fill input-group",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                        className: "form-select rounded-0",
                        name: "i_field",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "1",
                                children: "Yes"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "0",
                                children: "No"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                    children: "Country/City"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex-fill input-group",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            name: "q",
                            type: "text",
                            className: "form-control bg-white rounded-0 p-0 px-1",
                            placeholder: "Country/City"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "d-flex input-group-append",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "d-flex btn-group",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "btn btn-outline-secondary rounded-0",
                                    id: "search_button",
                                    role: "button",
                                    title: "Go Search",
                                    style: {
                                        padding: "2px 5px"
                                    },
                                    href: "#",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "material-icons",
                                        style: {
                                            verticalAlign: "middle"
                                        },
                                        children: "search"
                                    })
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                    className: "btn btn-sm btn-primary bg-blue ms-2 rounded-0 d-flex flex-row align-items-center shadow-sm",
                    "data-bs-toggle": "modal",
                    "data-bs-target": "#createSupEmerg",
                    onClick: ()=>setIsEdit(false),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            className: "material-icons fs-6",
                            style: {
                                verticalAlign: "middle"
                            },
                            children: "add"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "ms-2",
                            children: "Tambah"
                        })
                    ]
                })
            ]
        })
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "d-flex flex-column h-100 stdForm",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "stdFormBody flex-fill bg-white p-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mx-3",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row p-3",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-lg-6",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-dark mb-1 mt-4",
                                            children: "Supplier List"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "stdFormHeader flex-shrink-1",
                                            children: toolbarSupList
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "bg-white",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                className: "table table-bordered table-hover table-striped",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "5%",
                                                                    children: "Code"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "25%",
                                                                    children: "Name"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "10%",
                                                                    children: "Credit Day"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "5%",
                                                                    children: "Telephone"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "20%",
                                                                    children: "Action"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                        children: state?.data?.rows?.map((entry, index)=>{
                                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                    onClick: ()=>handleRowClick(index),
                                                                    className: "pointer",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                            children: entry.code
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                            children: entry.name
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                            children: entry.creditDay
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                            children: entry.mobile
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                type: "button",
                                                                                class: "btn btn-primary bg-blue",
                                                                                "data-bs-toggle": "modal",
                                                                                "data-bs-target": "#createHotel",
                                                                                onClick: ()=>{
                                                                                    setIsEdit(true);
                                                                                    setSelectedData(entry);
                                                                                },
                                                                                children: "Edit"
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            }, entry.id);
                                                        })
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-dark mb-1 mt-4",
                                            children: "Supplier API"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "stdFormHeader flex-shrink-1",
                                            children: toolbarSupEndpoint
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "bg-white",
                                            children: isOpenManager && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                className: "table table-bordered table-hover table-striped",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "15%",
                                                                    children: "Name"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "15%",
                                                                    children: "Method"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "10%",
                                                                    children: "Action"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                        children: state.data.rows.map((entry, index)=>{
                                                            if (selectedRowIndex === index && entry.suppApi && entry.suppApi.length > 0) {
                                                                return entry.suppApi.map((data)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: data.name
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: data.method
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                                children: [
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                        type: "button",
                                                                                        class: "btn btn-primary bg-blue",
                                                                                        "data-bs-toggle": "modal",
                                                                                        "data-bs-target": "#createSupEndpoint",
                                                                                        onClick: ()=>{
                                                                                            setIsEdit(true);
                                                                                            setSelectedData(data);
                                                                                        },
                                                                                        children: "Edit"
                                                                                    }),
                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                        type: "button",
                                                                                        className: "btn btn-warning ms-2",
                                                                                        children: "Detail"
                                                                                    })
                                                                                ]
                                                                            })
                                                                        ]
                                                                    }));
                                                            }
                                                        })
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-dark mb-1 mt-4",
                                            children: "Markup By Section"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "d-flex flex-row align-items-center bg-light p-2",
                                            style: {
                                                borderBottom: "1px solid #dddddd"
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex-fill input-group",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        name: "markup_start1",
                                                        type: "text",
                                                        className: "form-control bg-gray rounded-0 p-0 px-1",
                                                        value: "0",
                                                        disabled: "true"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                                                    children: "~"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex-fill input-group",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        name: "markup_end1",
                                                        type: "number",
                                                        className: "form-control bg-white rounded-0 p-0 px-1",
                                                        value: markupEndValues[0],
                                                        onChange: handleMarkupEnd1Change
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                                                    children: "Net"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex-fill input-group",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        name: "markup_net1",
                                                        type: "text",
                                                        className: "form-control bg-white rounded-0 p-0 px-1",
                                                        value: "0"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex-fill input-group",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                        className: "form-control bg-white rounded-0 p-0 px-1",
                                                        name: "markup_type1",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                value: "1",
                                                                children: "Percentage(%)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                value: "2",
                                                                children: "Fix Amount"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        [
                                            ...Array(numDivs - 1)
                                        ].map((_, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "d-flex flex-row align-items-center bg-light p-2",
                                                style: {
                                                    borderBottom: "1px solid #dddddd"
                                                },
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "d-flex flex-row align-items-center bg-light p-2",
                                                    style: {
                                                        borderBottom: "1px solid #dddddd"
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "flex-fill input-group",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                name: `markup_start${index + 2}`,
                                                                type: "text",
                                                                className: "form-control bg-gray rounded-0 p-0 px-1",
                                                                value: "0",
                                                                disabled: true
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                                                            children: "~"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "flex-fill input-group",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                name: `markup_end${index + 2}`,
                                                                type: "text",
                                                                className: "form-control bg-white rounded-0 p-0 px-1",
                                                                value: markupEndValues[index],
                                                                onChange: (e)=>handleMarkupEndInputChange(index, e.target.value)
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                                                            children: "Net"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "flex-fill input-group",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                name: `markup_net${index + 2}`,
                                                                type: "text",
                                                                className: "form-control bg-white rounded-0 p-0 px-1",
                                                                value: "0"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "flex-fill input-group",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                className: "form-control bg-white rounded-0 p-0 px-1",
                                                                name: `markup_type${index + 2}`,
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "1",
                                                                        children: "Percentage(%)"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "2",
                                                                        children: "Fix Amount"
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                }, index)
                                            }))
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-lg-6",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-dark mb-1",
                                            children: "Supplier Manager Information"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "stdFormHeader flex-shrink-1",
                                            children: toolbarSupMan
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "bg-white",
                                            children: isOpenManager && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                className: "table table-bordered table-hover table-striped",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "15%",
                                                                    children: "User ID"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "30%",
                                                                    children: "Name"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "5%",
                                                                    children: "Mobile"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "5%",
                                                                    children: "Email"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                        children: state.data.rows.map((entry, index)=>{
                                                            if (selectedRowIndex === index && entry.suppMan && entry.suppMan.length > 0) {
                                                                return entry.suppMan.map((data)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                        onClick: ()=>handleRowMan(index),
                                                                        className: "pointer",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: data.uid
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: data.name
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: data.mobile
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: data.email
                                                                            })
                                                                        ]
                                                                    }));
                                                            }
                                                        })
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-dark mb-1",
                                            children: "Supplier Emergency Contact Information"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "stdFormHeader flex-shrink-1",
                                            children: toolbarSupEmerg
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "bg-white",
                                            children: isOpenEmergency && selectedRowManIndex !== null && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                                className: "table table-bordered table-hover table-striped",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "30%",
                                                                    children: "Nation/City"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "35%",
                                                                    children: "Telephone 1"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    className: "bg-blue text-white",
                                                                    width: "35%",
                                                                    children: "Telephone 2"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                        children: state.data.rows[selectedRowManIndex]?.suppMan.map((manager)=>{
                                                            // Check if the manager has suppEmerg data
                                                            if (state.data.rows[selectedRowIndex].suppMan.length > 0 && manager.suppEmerg && manager.suppEmerg.length > 0) {
                                                                return manager.suppEmerg.map((data)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: data.short_name
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: data.phoneFirst
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                                children: data.phoneSecond
                                                                            })
                                                                        ]
                                                                    }, data.id));
                                                            }
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_createSupListForm__WEBPACK_IMPORTED_MODULE_5__["default"], {
                id: "createHotel",
                size: "modal-xl",
                isEdit: isEdit,
                selectedData: selectedData,
                handleGet: handleGet
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_createSupEndpointForm__WEBPACK_IMPORTED_MODULE_8__["default"], {
                id: "createSupEndpoint",
                size: "modal-xl",
                isEdit: isEdit,
                selectedData: selectedData,
                handleGet: handleGet
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_createSupManForm__WEBPACK_IMPORTED_MODULE_6__["default"], {
                id: "createSupMan",
                size: "modal-xl",
                isEdit: isEdit,
                selectedData: selectedData,
                handleGet: handleGet
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_createSupEmergForm__WEBPACK_IMPORTED_MODULE_7__["default"], {
                id: "createSupEmerg",
                size: "modal-xl",
                isEdit: isEdit,
                selectedData: selectedData,
                handleGet: handleGet
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;