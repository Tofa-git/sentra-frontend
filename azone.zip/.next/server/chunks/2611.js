"use strict";
exports.id = 2611;
exports.ids = [2611];
exports.modules = {

/***/ 2611:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$C": () => (/* binding */ getAllBookSearchRoom),
/* harmony export */   "Ar": () => (/* binding */ getAllBookList),
/* harmony export */   "IY": () => (/* binding */ createBook),
/* harmony export */   "IZ": () => (/* binding */ getAllBookSearch),
/* harmony export */   "d$": () => (/* binding */ cancelBooking),
/* harmony export */   "vI": () => (/* binding */ getDetailBook),
/* harmony export */   "yn": () => (/* binding */ recheckBookSearch)
/* harmony export */ });
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const getAllBookSearch = async (dispatch, body)=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_SEARCH_PROCESS */ .bk
    });
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/search-hotel`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const book = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Search Success", "Check list hotel Available on the Table", "success");
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_SEARCH_SUCCESS */ .Rb,
            payload: book.data
        });
        return {
            data: book?.data,
            status: book.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_SEARCH_FAILED */ .ad,
            payload: error
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Search Failed", "Error when search hotel, please try again later", "error");
        return {
            data: [],
            status: 500
        };
    }
};
const getAllBookSearchRoom = async (body, supplierId)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/search-hotel-room/${supplierId}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const book = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return {
            data: book?.data,
            status: book.status
        };
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Searching Room Failed", "Error when searching room hotel, please try again later", "error");
        return {
            data: [],
            status: 500
        };
    }
};
const getAllBookList = async (dispatch, page = 1, limit = 12, name = "")=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_LIST_PROCESS */ .pj
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/booking-list?page=${page}&limit=${limit}`;
        if (name.length > 0) {
            url += `&name=${name}`;
        }
        const token = localStorage.getItem("AUTH_TOKEN");
        const book = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(url, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Get List Success", "Successfully get list booking", "success");
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_LIST_SUCCESS */ .v,
            payload: book.data
        });
        return {
            data: book?.data,
            status: book.status
        };
    } catch (error) {
        console.log(error);
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_LIST_FAILED */ .sf,
            payload: error
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Get List Failed", "Error when Get List booking, please try again later", "error");
        return {
            data: [],
            status: 500
        };
    }
};
const recheckBookSearch = async (body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/recheck`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const book = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return {
            data: book?.data,
            status: book.status
        };
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Recheck Failed", "Error when recheck hotel, please try again later", "error");
        return {
            data: [],
            status: 500
        };
    }
};
const createBook = async (body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/booking`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const book = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Book Success", `Successfully booked, your Booking ID is: ${book.data.data.mgBookingID}`, "success");
        return {
            data: book?.data,
            status: book.status
        };
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Booking Failed", "Error when booking hotel, please try again later", "error");
        return {
            data: [],
            status: 500
        };
    }
};
const getDetailBook = async (dispatch, bookingId)=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_DETAIL_PROCESS */ .S7
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/booking-detail/${bookingId}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const book = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(url, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_DETAIL_SUCCESS */ .Yk,
            payload: book.data
        });
        return {
            data: book?.data,
            status: book.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .BOOK_DETAIL_FAILED */ .sd,
            payload: error
        });
        return {
            data: [],
            status: 500
        };
    }
};
const cancelBooking = async (bookingId)=>{
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/booking-cancel/${bookingId}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const book = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].put(url, {}, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return {
            data: book?.data,
            status: book.status
        };
    } catch (error) {
        console.log(error);
        return {
            data: [],
            status: 500,
            message: error.response.data.message
        };
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;