"use strict";
exports.id = 8475;
exports.ids = [8475];
exports.modules = {

/***/ 8475:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_input__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7267);
/* harmony import */ var _components_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2857);
/* harmony import */ var _context_city_reducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8796);
/* harmony import */ var _context_cityLocation_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4882);
/* harmony import */ var _context_country_reducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3363);
/* harmony import */ var _context_hotel_actions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(487);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_hotel_actions__WEBPACK_IMPORTED_MODULE_7__]);
_context_hotel_actions__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









// const Map = dynamic(() => import("../../components/map/index"), { ssr: false });
const initForm = {
    salesOffice: "",
    name: "",
    code: "",
    email: "",
    phone: "",
    address: "",
    password: "",
    status: "1",
    fileIds: []
};
const statusData = [
    {
        id: "1",
        name: "Yes"
    },
    {
        id: "0",
        name: "No"
    }
];
const CreateForm = (props)=>{
    const { isEdit , selectedData  } = props;
    const [form, setForm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initForm);
    const { state: countryState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country_reducer__WEBPACK_IMPORTED_MODULE_6__/* .CountryContext */ .o);
    const { state: cityState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_city_reducer__WEBPACK_IMPORTED_MODULE_4__/* .CityContext */ .i);
    const { state: cityLocationState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_cityLocation_reducer__WEBPACK_IMPORTED_MODULE_5__/* .CityLocationContext */ .O);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setForm(isEdit ? selectedData : initForm);
    }, [
        selectedData,
        isEdit
    ]);
    const handleInputChange = (name, value)=>{
        setForm({
            ...form,
            [name]: value
        });
    };
    const handleSubmit = async ()=>{
        const requiredField = [
            "salesOffice",
            "code",
            "name",
            "password",
            "address",
            "phone",
            "email",
            "status"
        ];
        const hasError = requiredField.filter((i)=>form[i] === 0 || form[i]?.length === 0);
        if (hasError.length > 0) {
            return sweetalert2__WEBPACK_IMPORTED_MODULE_8___default().fire("Validate", `Field ${hasError.join(", ").toLocaleUpperCase()} can't empty or 0`, "warning");
        }
        // const requiredField = ["name", "code", "latitude", "longitude"];
        // const hasError = requiredField.filter(
        //   (i) => form[i] === 0 || form[i]?.length === 0
        // );
        // if (hasError.length > 0) {
        //   return Swal.fire(
        //     "Validate",
        //     `Field ${hasError.join(", ").toLocaleUpperCase()} can't empty or 0`,
        //     "warning"
        //   );
        // }
        if (isEdit) {
            await (0,_context_hotel_actions__WEBPACK_IMPORTED_MODULE_7__/* .updateHotel */ .cB)(selectedData.id, form);
        } else {
            await (0,_context_hotel_actions__WEBPACK_IMPORTED_MODULE_7__/* .createHotel */ .dZ)(form);
        }
        await props.handleGet();
        document.getElementById("cancelModal").click();
    };
    const handleCancel = ()=>{
        setForm(initForm);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "modal fade",
        id: props.id,
        tabIndex: "-1",
        "aria-labelledby": "exampleModalLabel",
        "aria-hidden": "true",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: props.size + " modal-dialog",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "modal-content rounded-2 shadow",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-header",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                className: "modal-title fs-5 text-black",
                                id: props.id + "Label",
                                children: [
                                    isEdit ? "Edit" : "Add",
                                    " Operator Management"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn-close",
                                "data-bs-dismiss": "modal",
                                "aria-label": "Close",
                                onClick: ()=>handleCancel()
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-body p-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-blue fs-5 fw-bold border-bottom",
                                children: "Basic Section"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row mt-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "UID",
                                            value: form.code,
                                            onChange: (val)=>handleInputChange("code", val.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "PASSWORD",
                                            value: form.password,
                                            onChange: (val)=>handleInputChange("password", val.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "NAME",
                                            value: form.name,
                                            onChange: (val)=>handleInputChange("name", val.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "HP",
                                            value: form.phone,
                                            onChange: (val)=>handleInputChange("phone", val.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "E-MAIL",
                                            value: form.email,
                                            onChange: (val)=>handleInputChange("email", val.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "ADDRESS",
                                            value: form.address,
                                            onChange: (val)=>handleInputChange("address", val.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "Sales Office",
                                            value: form.salesOffice,
                                            options: countryState?.dropdownData,
                                            onChange: (val)=>handleInputChange("salesOffice", val.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "USED",
                                            options: statusData,
                                            value: form.status,
                                            onChange: (val)=>handleInputChange("status", val.target.value)
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-footer",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn btn-danger rounded-0",
                                "data-bs-dismiss": "modal",
                                id: "cancelModal",
                                onClick: ()=>handleCancel(),
                                children: "Cancel"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>{
                                    handleSubmit();
                                },
                                type: "button",
                                className: "btn btn-primary rounded-0",
                                children: isEdit ? "Edit" : "Add"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;