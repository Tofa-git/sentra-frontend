"use strict";
exports.id = 6304;
exports.ids = [6304];
exports.modules = {

/***/ 9663:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var reactjs_stylesheet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1027);
/* harmony import */ var reactjs_stylesheet__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(reactjs_stylesheet__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _menu_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2177);





const ImgButton = ({ id , caption , icon , type , subMenu , target  })=>{
    const [buildSubMenu, setBuildSubMenu] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const subMenus = (refid)=>{
        const renderSubMenu = _menu_js__WEBPACK_IMPORTED_MODULE_4__/* ["default"].filter */ .Z.filter((menus)=>menus.headid.includes(refid));
        setBuildSubMenu(renderSubMenu);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        subMenus(id);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: {
            1: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                href: target ?? "/#",
                className: "border d-flex align-items-center hover-dark p-1 px-2",
                style: styles.imgButton,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                        className: "material-icons fs-6 text-secondary",
                        children: icon
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "ms-2 small text-secondary",
                        children: caption
                    })
                ]
            }),
            2: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "btn-group",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        className: "dropdown-toggle border d-flex align-items-center hover-dark p-1 px-2",
                        style: styles.imgButton,
                        "data-bs-toggle": "dropdown",
                        "aria-expanded": "false",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "material-icons fs-6 text-secondary",
                                children: icon
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "ms-2 small text-secondary",
                                children: caption
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "dropdown-menu shadow-sm",
                        children: buildSubMenu.map((menu)=>({
                                1: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            href: menu.target ?? "/#",
                                            className: "dropdown-item small",
                                            children: menu.caption
                                        })
                                    })
                                }, menu.id),
                                3: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_2___default().Fragment), {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                            className: "dropdown-divider"
                                        })
                                    })
                                }, menu.id)
                            })[menu.type])
                    })
                ]
            }),
            3: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: {
                    borderLeft: "1px solid #aaaaaa",
                    margin: "0px 3px"
                }
            })
        }[type]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImgButton);
const styles = reactjs_stylesheet__WEBPACK_IMPORTED_MODULE_3___default().create({
    imgButton: {
        border: "none",
        backgroundColor: "transparent"
    }
});


/***/ }),

/***/ 6919:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Footers = (props)=>{
    const [tanggal, setTanggal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const getDate = ()=>{
        let newDate = new Date();
        let tgl = newDate.getMonth();
        let hari = newDate.getDate();
        if (tgl < 10) {
            tgl = "0" + tgl;
        }
        if (hari < 10) {
            hari = "0" + hari;
        }
        setTanggal(hari + "-" + tgl + "-" + newDate.getFullYear());
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getDate();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "d-flex",
            style: {
                borderTop: "1px solid #dddddd",
                backgroundColor: "#eeeeee"
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                className: "p-0 px-2 d-flex flex-fill flex-justify-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "w-100 small m-0 p-0 text-secondary",
                        children: "Login as Administrator"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "flex-shrink-1 text-nowrap border small m-0 p-0 text-secondary",
                        children: tanggal
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footers);


/***/ }),

/***/ 5500:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Headers = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "d-flex headerBlue m-0 p-0",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        className: "d-flex align-items-center hover-dark btn btn-primary bg-transparent rounded-0 shadow-none p-2",
                        style: {
                            border: "none"
                        },
                        "data-bs-toggle": "offcanvas",
                        href: "#offcanvasExample",
                        role: "button",
                        "aria-controls": "offcanvasExample",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            className: "material-icons",
                            children: "apps"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        className: "p-0 d-flex align-items-center px-2 cursor-default",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "small m-0 p-0 text-light fs-6",
                            children: "Extra-Net Solution Network (ESN)"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "offcanvas offcanvas-start",
                tabIndex: "-1",
                id: "offcanvasExample",
                "aria-labelledby": "offcanvasExampleLabel",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "offcanvas-header",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "offcanvas-title",
                                id: "offcanvasExampleLabel",
                                children: "Offcanvas"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn-close",
                                "data-bs-dismiss": "offcanvas",
                                "aria-label": "Close"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "offcanvas-body",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: "Some text as placeholder. In real life you can have the elements you have chosen. Like, text, images, lists, etc."
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "dropdown mt-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "btn btn-secondary dropdown-toggle",
                                        type: "button",
                                        "data-bs-toggle": "dropdown",
                                        children: "Dropdown button"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                        className: "dropdown-menu",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "dropdown-item",
                                                    href: "#",
                                                    children: "Action"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "dropdown-item",
                                                    href: "#",
                                                    children: "Another action"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "dropdown-item",
                                                    href: "#",
                                                    children: "Something else here"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Headers);


/***/ }),

/***/ 1714:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ribbon)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(9332);
// EXTERNAL MODULE: external "reactjs-stylesheet"
var external_reactjs_stylesheet_ = __webpack_require__(1027);
var external_reactjs_stylesheet_default = /*#__PURE__*/__webpack_require__.n(external_reactjs_stylesheet_);
;// CONCATENATED MODULE: ./components/button/tabRibbon.js


const TabRibbon = ({ id , id_active , labels , clickRibbon  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
            className: "d-flex align-items-center hover-dark px-3",
            style: id !== id_active ? styles.tabRibbon : styles.tabRibbonActive,
            onClick: ()=>clickRibbon(id),
            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "small p-1 text-dark",
                children: labels
            })
        })
    });
};
/* harmony default export */ const tabRibbon = (TabRibbon);
const styles = external_reactjs_stylesheet_default().create({
    tabRibbon: {
        border: "none",
        backgroundColor: "transparent",
        borderBottom: "4px solid transparent"
    },
    tabRibbonActive: {
        border: "none",
        backgroundColor: "transparent",
        borderBottom: "4px solid darkBlue"
    }
});

// EXTERNAL MODULE: ./components/button/imgButton.js
var imgButton = __webpack_require__(9663);
// EXTERNAL MODULE: ./components/menu.js
var menu = __webpack_require__(2177);
;// CONCATENATED MODULE: ./components/subRibbon/subRibbon.js





const SubRibbon = ({ loadMenu  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "d-flex gap-1",
        children: loadMenu.map((menu)=>/*#__PURE__*/ jsx_runtime_.jsx((external_react_default()).Fragment, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(imgButton/* default */.Z, {
                    id: menu.id,
                    caption: menu.caption,
                    icon: menu.icon,
                    type: menu.type,
                    target: menu.target
                })
            }, menu.id))
    });
};
/* harmony default export */ const subRibbon = (SubRibbon);

// EXTERNAL MODULE: ./context/auth/reducer.js
var reducer = __webpack_require__(1118);
// EXTERNAL MODULE: ./context/constant.js
var constant = __webpack_require__(6552);
;// CONCATENATED MODULE: ./components/layouts/ribbon.js









const Ribbons = (props)=>{
    const router = (0,navigation.useRouter)();
    const { dispatch  } = (0,external_react_.useContext)(reducer/* AuthContext */.V);
    const [selectId, setSelectId] = (0,external_react_.useState)(props.selected);
    const [buildMenu, setBuildMenu] = (0,external_react_.useState)(menu/* default.filter */.Z.filter((menus)=>menus.refid.includes(selectId)));
    const clickRibbon = (el)=>{
        setSelectId(el);
        const renderMenu = menu/* default.filter */.Z.filter((menus)=>menus.refid.includes(el));
        setBuildMenu(renderMenu);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "d-flex flex-row shadow-sm p-0 px-2 justify-content-between",
                style: ribbon_styles.containerRibbon,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "d-flex flex-row flex-fill",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(tabRibbon, {
                                labels: "Home",
                                id: "001",
                                id_active: selectId,
                                clickRibbon: clickRibbon
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(tabRibbon, {
                                labels: "Basic",
                                id: "002",
                                id_active: selectId,
                                clickRibbon: clickRibbon
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(tabRibbon, {
                                labels: "Hotel Info",
                                id: "006",
                                id_active: selectId,
                                clickRibbon: ()=>router.push("/data-hotel")
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(tabRibbon, {
                                labels: "Management",
                                id: "003",
                                id_active: selectId,
                                clickRibbon: clickRibbon
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(tabRibbon, {
                                labels: "Statistic",
                                id: "004",
                                id_active: selectId,
                                clickRibbon: clickRibbon
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(tabRibbon, {
                                labels: "Member",
                                id: "005",
                                id_active: selectId,
                                clickRibbon: clickRibbon
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        onClick: ()=>{
                            dispatch({
                                type: constant/* AUTH_LOGOUT */.LQ
                            });
                            router.push("/authentication/login");
                        },
                        className: "btn btn-sm btn-primary bg-blue rounded shadow-sm mt-1 mt-1",
                        children: [
                            "Logout",
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "material-icons fs-6 ms-2",
                                style: {
                                    verticalAlign: "middle"
                                },
                                children: "logout"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "p-1",
                style: ribbon_styles.containerSubRibbon,
                children: /*#__PURE__*/ jsx_runtime_.jsx(subRibbon, {
                    loadMenu: buildMenu
                })
            })
        ]
    });
};
/* harmony default export */ const ribbon = (Ribbons);
const ribbon_styles = external_reactjs_stylesheet_default().create({
    containerRibbon: {
        maxHeight: "40px",
        minHeight: "30px",
        backgroundColor: "#eeeeee"
    },
    containerSubRibbon: {
        backgroundColor: "white",
        borderBottom: "1px solid #aaaaaa"
    }
});


/***/ }),

/***/ 2177:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const DataMenu = [
    {
        id: "1",
        refid: "001",
        headid: "0",
        type: "1",
        caption: "Dashboard",
        target: "/dashboard",
        icon: "dashboard"
    },
    {
        id: "2",
        refid: "001",
        headid: "0",
        type: "1",
        caption: "Booking",
        target: "/booking",
        icon: "event"
    },
    {
        id: "3",
        refid: "002",
        headid: "0",
        type: "2",
        caption: "Code",
        target: "/#",
        icon: "dashboard"
    },
    {
        id: "4",
        refid: "002",
        headid: "0",
        type: "2",
        caption: "Mapping",
        target: "/#",
        icon: "account_tree"
    },
    {
        id: "5",
        refid: "002",
        headid: "0",
        type: "1",
        caption: "XML Link Control",
        target: "/link-control",
        icon: "dataset_linked"
    },
    {
        id: "6",
        refid: "002",
        headid: "0",
        type: "3",
        caption: "",
        icon: ""
    },
    {
        id: "7",
        refid: "002",
        headid: "0",
        type: "1",
        caption: "Company Information",
        icon: "home_work"
    },
    {
        id: "8",
        refid: "002",
        headid: "0",
        type: "3",
        caption: "",
        icon: ""
    },
    {
        id: "9",
        refid: "002",
        headid: "0",
        type: "1",
        caption: "Screen Translate",
        target: "/screen-translate",
        icon: "monitor"
    },
    {
        id: "10",
        refid: "003",
        headid: "0",
        type: "2",
        caption: "Currency",
        icon: "currency_exchange"
    },
    {
        id: "11",
        refid: "",
        headid: "3",
        type: "1",
        caption: "Country Code",
        target: "/code/country-code",
        icon: "dashboard"
    },
    {
        id: "12",
        refid: "",
        headid: "3",
        type: "1",
        caption: "City Code",
        target: "/code/city-code",
        icon: "dashboard"
    },
    {
        id: "13",
        refid: "005",
        headid: "0",
        type: "2",
        caption: "Operator",
        icon: "people"
    },
    {
        id: "14",
        refid: "005",
        headid: "0",
        type: "2",
        caption: "Agent",
        icon: "people"
    },
    {
        id: "15",
        refid: "005",
        headid: "0",
        type: "2",
        caption: "Supplier",
        icon: "people"
    },
    {
        id: "16",
        refid: "005",
        headid: "0",
        type: "2",
        caption: "Authority",
        icon: "people"
    },
    {
        id: "31",
        refid: "",
        headid: "3",
        type: "1",
        caption: "Nationality Code",
        target: "/code/nationality-code",
        icon: "dashboard"
    },
    {
        id: "13",
        refid: "",
        headid: "3",
        type: "3",
        caption: "",
        target: "/#",
        icon: ""
    },
    {
        id: "14",
        refid: "",
        headid: "3",
        type: "1",
        caption: "Region",
        target: "/code/region-code",
        icon: "dashboard"
    },
    {
        id: "15",
        refid: "",
        headid: "3",
        type: "1",
        caption: "City Location",
        target: "/code/city-location",
        icon: "dashboard"
    },
    {
        id: "16",
        refid: "",
        headid: "3",
        type: "3",
        caption: "",
        target: "/#",
        icon: ""
    },
    // {
    //   id: "17",
    //   refid: "",
    //   headid: "3",
    //   type: "1",
    //   caption: "Facilities - Hotel",
    //   target: "/code/facilities-hotel",
    //   icon: "dashboard",
    // },
    {
        id: "32",
        refid: "",
        headid: "3",
        type: "1",
        caption: "Facilities",
        target: "/code/facilities-room",
        icon: "dashboard"
    },
    {
        id: "18",
        refid: "",
        headid: "3",
        type: "1",
        caption: "Breakfast Code",
        target: "/code/breakfast-code",
        icon: "dashboard"
    },
    {
        id: "19",
        refid: "",
        headid: "3",
        type: "1",
        caption: "Meal Code",
        target: "/code/meal-code",
        icon: "dashboard"
    },
    {
        id: "19",
        refid: "",
        headid: "3",
        type: "1",
        caption: "Bed Type",
        target: "/code/bed-type",
        icon: "dashboard"
    },
    {
        id: "19",
        refid: "",
        headid: "3",
        type: "1",
        caption: "Room Grade",
        target: "/code/room-grade",
        icon: "dashboard"
    },
    {
        id: "20",
        refid: "",
        headid: "3",
        type: "3",
        caption: "",
        target: "/#",
        icon: ""
    },
    {
        id: "21",
        refid: "",
        headid: "3",
        type: "1",
        caption: "CXL Policy",
        target: "/code/cxl-policy",
        icon: "dashboard"
    },
    {
        id: "22",
        refid: "",
        headid: "3",
        type: "1",
        caption: "Payment Method",
        target: "/code/payment-method",
        icon: "dashboard"
    },
    {
        id: "23",
        refid: "",
        headid: "3",
        type: "1",
        caption: "Season Type",
        target: "/code/season-type",
        icon: "dashboard"
    },
    {
        id: "24",
        refid: "",
        headid: "3",
        type: "3",
        caption: "",
        target: "/#",
        icon: ""
    },
    {
        id: "25",
        refid: "",
        headid: "3",
        type: "1",
        caption: "Setup Calendar",
        target: "/code/setup-calendar",
        icon: "dashboard"
    },
    {
        id: "26",
        refid: "",
        headid: "4",
        type: "1",
        caption: "Country Mapping",
        target: "/mapping/country",
        icon: "dashboard"
    },
    {
        id: "27",
        refid: "",
        headid: "4",
        type: "1",
        caption: "City Mapping",
        target: "/mapping/city",
        icon: "dashboard"
    },
    {
        id: "28",
        refid: "",
        headid: "4",
        type: "1",
        caption: "Hotel Mapping",
        target: "/mapping/hotel",
        icon: "dashboard"
    },
    {
        id: "29",
        refid: "",
        headid: "10",
        type: "1",
        caption: "Master Currency",
        target: "/currency/master-currency",
        icon: "dashboard"
    },
    {
        id: "30",
        refid: "",
        headid: "10",
        type: "1",
        caption: "Exchange Rate",
        target: "/currency/exchange-rate",
        icon: "dashboard"
    },
    //#region Operator
    {
        id: "30",
        refid: "",
        headid: "13",
        type: "1",
        caption: "Operator Management",
        target: "/operator",
        icon: "dashboard"
    },
    //#endregion
    //#region Agent
    {
        id: "31",
        refid: "",
        headid: "14",
        type: "1",
        caption: "Agent Management",
        target: "/operator",
        icon: "dashboard"
    },
    //#endregion
    //#region Supplier
    {
        id: "32",
        refid: "",
        headid: "15",
        type: "1",
        caption: "Supplier Management",
        target: "/supplier",
        icon: "dashboard"
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DataMenu);


/***/ }),

/***/ 195:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JY": () => (/* binding */ getAllCurrency)
/* harmony export */ });
/* unused harmony exports createCurrency, updateCurrency, deleteCurrency */
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const getAllCurrency = async (dispatch, isDropDown = false, page = 1, limit = 12, name = "")=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .CURRENCY_PROCESS */ .vw
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/currency?page=${page}&limit=${limit}`;
        if (name.length > 0) {
            url += `&name=${name}`;
        }
        if (isDropDown) {
            url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/currency-dd`;
        }
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .CURRENCY_SUCCESS */ .Ur,
            payload: {
                data: data?.data,
                isDropDown
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .CURRENCY_FAILED */ .Am,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
const createCurrency = async (body)=>{
    try {
        const url = `${baseUrl}/api/master/currency/`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Create Success", "Currency has been successfully created", "success");
    } catch (error) {
        Swal.fire("Create Failed", "Error when create Currency, please try again later", "error");
    }
};
const updateCurrency = async (id, body)=>{
    try {
        const url = `${baseUrl}/api/master/currency/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.put(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Update Success", "Currency has been successfully updated", "success");
    } catch (error) {
        Swal.fire("Update Failed", "Error when update Currency, please try again later", "error");
    }
};
const deleteCurrency = async (id)=>{
    try {
        const url = `${baseUrl}/api/master/currency/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.delete(url, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Delete Success", "Currency has been successfully deleted", "success");
    } catch (error) {
        Swal.fire("Delete Failed", "Error when delete Currency, please try again later", "error");
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6304:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_layouts_header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5500);
/* harmony import */ var _components_layouts_ribbon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1714);
/* harmony import */ var _components_layouts_footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6919);
/* harmony import */ var _context_auth_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1118);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _context_constant__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(6552);
/* harmony import */ var material_icons_iconfont_material_icons_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3810);
/* harmony import */ var material_icons_iconfont_material_icons_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(material_icons_iconfont_material_icons_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _context_country_reducer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3363);
/* harmony import */ var _context_country_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3323);
/* harmony import */ var _context_currency_action__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(195);
/* harmony import */ var _context_currency_reducer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9968);
/* harmony import */ var _context_city_actions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8225);
/* harmony import */ var _context_city_reducer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8796);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _context_cityLocation_reducer__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4882);
/* harmony import */ var _context_cityLocation_actions__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(50);
/* harmony import */ var _context_nationality_actions__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4541);
/* harmony import */ var _context_nationality_reducer__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6821);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_country_actions__WEBPACK_IMPORTED_MODULE_9__, _context_currency_action__WEBPACK_IMPORTED_MODULE_10__, _context_city_actions__WEBPACK_IMPORTED_MODULE_12__, _context_cityLocation_actions__WEBPACK_IMPORTED_MODULE_16__, _context_nationality_actions__WEBPACK_IMPORTED_MODULE_17__]);
([_context_country_actions__WEBPACK_IMPORTED_MODULE_9__, _context_currency_action__WEBPACK_IMPORTED_MODULE_10__, _context_city_actions__WEBPACK_IMPORTED_MODULE_12__, _context_cityLocation_actions__WEBPACK_IMPORTED_MODULE_16__, _context_nationality_actions__WEBPACK_IMPORTED_MODULE_17__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




















const Layout = ({ children , selectId  })=>{
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_reducer__WEBPACK_IMPORTED_MODULE_5__/* .AuthContext */ .V);
    const { state: countryState , dispatch: countryDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country_reducer__WEBPACK_IMPORTED_MODULE_8__/* .CountryContext */ .o);
    const { state: currencyState , dispatch: currencyDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_currency_reducer__WEBPACK_IMPORTED_MODULE_11__/* .CurrencyContext */ .$);
    const { state: cityState , dispatch: cityDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_city_reducer__WEBPACK_IMPORTED_MODULE_13__/* .CityContext */ .i);
    const { state: cityLocationState , dispatch: cityLocationDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_cityLocation_reducer__WEBPACK_IMPORTED_MODULE_15__/* .CityLocationContext */ .O);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const { dispatch: authDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_reducer__WEBPACK_IMPORTED_MODULE_5__/* .AuthContext */ .V);
    const { state: nationalityState , dispatch: nationalityDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_nationality_reducer__WEBPACK_IMPORTED_MODULE_18__/* .NationalityContext */ .M);
    const recheckToken = ()=>{
        const token = localStorage.getItem("AUTH_TOKEN");
        if (token) {
            dispatch({
                type: _context_constant__WEBPACK_IMPORTED_MODULE_19__/* .AUTH_SUCCESS */ .DP
            });
        }
        if (!state.isAuthenticated && !token) {
            router.push("/authentication/login");
        }
    };
    const getMasterData = ()=>{
        if (!countryState.hasOwnProperty("dropdownData") || countryState?.dropdownData.length === 0) {
            getMaster("country");
        }
        if (!cityState.hasOwnProperty("dropdownData") || cityState?.dropdownData.length === 0) {
            getMaster("city");
        }
        if (!countryState.hasOwnProperty("currencyData") || countryState.currencyData.length === 0) {
            getMaster("currency");
        }
        if (!currencyState.hasOwnProperty("dropdownData") || currencyState.dropdownData.length === 0) {
            getMaster("curr");
        }
        if (!nationalityState.hasOwnProperty("dropdownData") || nationalityState.dropdownData.length === 0) {
            getMaster("nationality");
        }
    // if (cityLocationState.dropdownData.length === 0) {
    //   getMaster("cityLocation");
    // }
    };
    const getMaster = async (name)=>{
        let data = null;
        if (name === "country") {
            data = await (0,_context_country_actions__WEBPACK_IMPORTED_MODULE_9__/* .getAllCountry */ .g_)(countryDispatch, true);
        } else if (name === "city") {
            data = await (0,_context_city_actions__WEBPACK_IMPORTED_MODULE_12__/* .getAllCity */ .G4)(cityDispatch, true);
        } else if (name === "currency") {
            data = await (0,_context_country_actions__WEBPACK_IMPORTED_MODULE_9__/* .getCurrencies */ .DE)(countryDispatch);
        } else if (name === "curr") {
            data = await (0,_context_currency_action__WEBPACK_IMPORTED_MODULE_10__/* .getAllCurrency */ .JY)(currencyDispatch, true);
        } else if (name === "cityLocation") {
            data = await (0,_context_cityLocation_actions__WEBPACK_IMPORTED_MODULE_16__/* .getAllCityLocation */ .$U)(cityLocationDispatch, true);
        } else if (name === "nationality") {
            data = await (0,_context_nationality_actions__WEBPACK_IMPORTED_MODULE_17__/* .getAllNationality */ .NI)(nationalityDispatch, true);
        }
        if (data?.status === 401) {
            handle401();
        }
    };
    const handle401 = ()=>{
        authDispatch({
            type: _context_constant__WEBPACK_IMPORTED_MODULE_19__/* .AUTH_401 */ .fR
        });
        authDispatch({
            type: _context_constant__WEBPACK_IMPORTED_MODULE_19__/* .AUTH_LOGOUT */ .LQ
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_14___default().fire("Token has been Expired", "Please Login Again", "warning");
        router.push("/authentication/login");
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        recheckToken();
        setTimeout(()=>{
            getMasterData();
        }, 5000);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "d-flex flex-column flex-fill min-vh-100",
            style: {
                backgroundColor: "#dddddd"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_header__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_ribbon__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    selected: selectId
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                    className: "flex-grow-1",
                    children: children
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;