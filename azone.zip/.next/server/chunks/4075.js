"use strict";
exports.id = 4075;
exports.ids = [4075];
exports.modules = {

/***/ 4075:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_cityLocation_actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(50);
/* harmony import */ var _context_country_reducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3363);
/* harmony import */ var _context_city_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8796);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_cityLocation_actions__WEBPACK_IMPORTED_MODULE_3__]);
_context_cityLocation_actions__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const initForm = {
    code: "",
    name: "",
    cityId: 0,
    status: ""
};
const CreateForm = (props)=>{
    const { isEdit , selectedData  } = props;
    const [form, setForm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initForm);
    const { state: countryState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country_reducer__WEBPACK_IMPORTED_MODULE_4__/* .CountryContext */ .o);
    const { state: cityState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_city_reducer__WEBPACK_IMPORTED_MODULE_5__/* .CityContext */ .i);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setForm(isEdit ? selectedData : initForm);
    }, [
        selectedData,
        isEdit
    ]);
    const handleInputChange = (name, value)=>{
        setForm({
            ...form,
            [name]: value
        });
    };
    const handleSubmit = async ()=>{
        const requiredField = [
            "code",
            "name",
            "cityId",
            "status"
        ];
        const hasError = requiredField.filter((i)=>form[i] === 0 || form[i]?.length === 0);
        if (hasError.length > 0) {
            return sweetalert2__WEBPACK_IMPORTED_MODULE_2___default().fire("Validate", `Field ${hasError.join(", ").toLocaleUpperCase()} can't empty or 0`, "warning");
        }
        if (isEdit) {
            await (0,_context_cityLocation_actions__WEBPACK_IMPORTED_MODULE_3__/* .updateCityLocation */ .zX)(selectedData.id, form);
        } else {
            await (0,_context_cityLocation_actions__WEBPACK_IMPORTED_MODULE_3__/* .createCityLocation */ .i1)(form);
        }
        await props.handleGet();
        document.getElementById("cancelModal").click();
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "modal fade",
        id: props.id,
        tabIndex: "-1",
        "aria-labelledby": "exampleModalLabel",
        "aria-hidden": "true",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: props.size + " modal-dialog",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "modal-content rounded-2 shadow",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-header",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                className: "modal-title fs-5 text-black",
                                id: props.id + "Label",
                                children: [
                                    isEdit ? "Edit" : "Add",
                                    " Location"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn-close",
                                "data-bs-dismiss": "modal",
                                "aria-label": "Close"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-body p-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row mt-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-sm-4 text-black",
                                        children: "Country"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-sm-8",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                className: "form-select rounded-0",
                                                name: "country",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "0",
                                                        children: "Choose Country"
                                                    }),
                                                    countryState?.dropdownData?.map((country)=>{
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            value: country.id,
                                                            children: country.name
                                                        });
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                className: "form-select rounded-0 mt-2",
                                                name: "cityId",
                                                value: form.cityId,
                                                onChange: (val)=>handleInputChange("cityId", val.target.value),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "0",
                                                        children: "Choose Location"
                                                    }),
                                                    cityState?.dropdownData?.map((city)=>{
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            value: city.id,
                                                            children: city.shortName
                                                        });
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row mt-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-sm-4 text-black",
                                        children: "Location Code"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-sm-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: "form-control rounded-0",
                                            value: form.code,
                                            onChange: (val)=>handleInputChange("code", val.target.value)
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row mt-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-sm-4 text-black",
                                        children: "Name"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-sm-8",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "text",
                                            className: "form-control rounded-0",
                                            value: form.name,
                                            onChange: (val)=>handleInputChange("name", val.target.value)
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row mt-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-sm-4 text-black",
                                        children: "Is Used"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-sm-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                            className: "form-select rounded-0",
                                            value: form.status,
                                            onChange: (val)=>handleInputChange("status", val.target.value),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                    value: "-",
                                                    children: "Choose Status"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                    value: "1",
                                                    children: "Yes"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                    value: "0",
                                                    children: "No"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "modal-footer",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn btn-danger rounded-0",
                                "data-bs-dismiss": "modal",
                                id: "cancelModal",
                                children: "Cancel"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>{
                                    handleSubmit();
                                },
                                type: "button",
                                className: "btn btn-primary rounded-0",
                                children: isEdit ? "Edit" : "Add"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;