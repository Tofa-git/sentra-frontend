"use strict";
exports.id = 850;
exports.ids = [850];
exports.modules = {

/***/ 4158:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Np": () => (/* binding */ getAllSales)
/* harmony export */ });
/* unused harmony exports createSales, updateSales, deleteSales */
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const getAllSales = async (dispatch, isDropDown = false, page = 1, limit = 12, name = "")=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .SALES_OFFICE_PROCESS */ .oI
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/userSales?page=${page}&limit=${limit}`;
        if (name.length > 0) {
            url += `&name=${name}`;
        }
        if (isDropDown) {
            url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/userSale-dd`;
        }
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .SALES_OFFICE_SUCCESS */ .PG,
            payload: {
                data: data?.data,
                isDropDown
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .SALES_OFFICE_FAILED */ .a3,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
const createSales = async (body)=>{
    try {
        const url = `${baseUrl}/api/userSale`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Create Success", "Sales Office has been successfully created", "success");
    } catch (error) {
        Swal.fire("Create Failed", "Error when create sales office, please try again later", "error");
    }
};
const updateSales = async (id, body)=>{
    try {
        const url = `${baseUrl}/api/userSale/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.put(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Update Success", "Sales Office has been successfully updated", "success");
    } catch (error) {
        Swal.fire("Update Failed", "Error when update sales office, please try again later", "error");
    }
};
const deleteSales = async (id)=>{
    try {
        const url = `${baseUrl}/api/userSale/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.delete(url, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Delete Success", "Sales Office has been successfully deleted", "success");
    } catch (error) {
        Swal.fire("Delete Failed", "Error when delete sales office, please try again later", "error");
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 850:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _layouts_default__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6304);
/* harmony import */ var _components_forms_stdForm__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3915);
/* harmony import */ var _createForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7839);
/* harmony import */ var _context_auth_reducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1118);
/* harmony import */ var _context_country_reducer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3363);
/* harmony import */ var _context_city_reducer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8796);
/* harmony import */ var _context_salesOffice_actions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4158);
/* harmony import */ var _context_salesOffice_reducer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3306);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layouts_default__WEBPACK_IMPORTED_MODULE_3__, _createForm__WEBPACK_IMPORTED_MODULE_5__, _context_salesOffice_actions__WEBPACK_IMPORTED_MODULE_9__]);
([_layouts_default__WEBPACK_IMPORTED_MODULE_3__, _createForm__WEBPACK_IMPORTED_MODULE_5__, _context_salesOffice_actions__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const Index = (props)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const selectedId = "006";
    const [selectedData, setSelectedData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [isEdit, setIsEdit] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [keyword, setKeyword] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_salesOffice_reducer__WEBPACK_IMPORTED_MODULE_10__/* .SalesOfficeContext */ .b);
    const { dispatch: authDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_reducer__WEBPACK_IMPORTED_MODULE_6__/* .AuthContext */ .V);
    const { state: countryState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country_reducer__WEBPACK_IMPORTED_MODULE_7__/* .CountryContext */ .o);
    const { state: cityState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_city_reducer__WEBPACK_IMPORTED_MODULE_8__/* .CityContext */ .i);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        handleGet();
    }, []);
    const handleGet = async (page = 1, limit = 12)=>{
        const sales = await (0,_context_salesOffice_actions__WEBPACK_IMPORTED_MODULE_9__/* .getAllSales */ .Np)(dispatch, false, page, limit, keyword);
        if (sales.status === 401) {
            authDispatch({
                type: AUTH_401
            });
            authDispatch({
                type: AUTH_LOGOUT
            });
            Swal.fire("Token has been Expired", "Please Login Again", "warning");
            router.push("/authentication/login");
        }
    };
    const toolbarForm = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "d-flex flex-row align-items-center bg-light p-2",
            style: {
                borderBottom: "1px solid #dddddd"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex-shrink-1 pe-1 ms-2 small text-nowrap text-dark",
                    children: "ID/Name"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex-fill input-group",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            name: "q",
                            type: "text",
                            className: "form-control bg-white rounded-0 p-0 px-1",
                            placeholder: "User ID/Name"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "d-flex input-group-append",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "d-flex btn-group",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "btn btn-outline-secondary rounded-0",
                                    id: "search_button",
                                    role: "button",
                                    title: "Go Search",
                                    style: {
                                        padding: "2px 5px"
                                    },
                                    href: "#",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "material-icons",
                                        style: {
                                            verticalAlign: "middle"
                                        },
                                        children: "search"
                                    })
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                    className: "btn btn-sm btn-primary bg-blue ms-2 rounded-0 d-flex flex-row align-items-center shadow-sm",
                    "data-bs-toggle": "modal",
                    "data-bs-target": "#createHotel",
                    onClick: ()=>setIsEdit(false),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            className: "material-icons fs-6",
                            style: {
                                verticalAlign: "middle"
                            },
                            children: "add"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "ms-2",
                            children: "Tambah"
                        })
                    ]
                })
            ]
        })
    });
    const bodyForm = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "table-wrapper rounded-0 d-flex h-100",
        style: {
            border: "1px solid #dddddd",
            backgroundColor: "#fff"
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-100",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                className: "table table-bordered table-hover table-striped",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                    className: "bg-blue text-white",
                                    width: "10%",
                                    children: "ID"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                    className: "bg-blue text-white",
                                    width: "40%",
                                    children: "SALES OFFICE NAME"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                    className: "bg-blue text-white",
                                    width: "40%",
                                    children: "SALES OFFICE MANAGER"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                    className: "bg-blue text-white",
                                    width: "10%",
                                    children: "ACTION"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                        children: state?.data?.rows?.map((data)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: data.username
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: data.name
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: data.manager
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            type: "button",
                                            class: "btn btn-primary bg-blue",
                                            "data-bs-toggle": "modal",
                                            "data-bs-target": "#createHotel",
                                            onClick: ()=>{
                                                setIsEdit(true);
                                                setSelectedData(data);
                                            },
                                            children: "Edit"
                                        })
                                    })
                                ]
                            });
                        })
                    })
                ]
            })
        })
    });
    const footers = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "d-flex justify-content-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
            "aria-label": "Page navigation example",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                class: "pagination",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        class: `page-item ${1 === state?.data?.page && "disabled"}`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            class: "page-link",
                            onClick: ()=>handleGet(state?.data?.page - 1),
                            children: "Previous"
                        })
                    }),
                    new Array(Number(state?.data?.totalPage)).fill().map((i, key)=>{
                        const current = key + 1;
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            class: `page-item ${current === state?.data?.page && "active"}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                class: "page-link",
                                onClick: ()=>handleGet(current),
                                children: current
                            })
                        });
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        class: `page-item ${!state?.data?.hasNext && "disabled"}`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            class: "page-link",
                            onClick: ()=>handleGet(state?.data?.page + 1),
                            children: "Next"
                        })
                    })
                ]
            })
        })
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_forms_stdForm__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                id: 1,
                // icon="grid_on"
                caption: "",
                toolbar: toolbarForm,
                body: bodyForm,
                footer: footers
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_createForm__WEBPACK_IMPORTED_MODULE_5__["default"], {
                id: "createHotel",
                size: "modal-xl",
                isEdit: isEdit,
                selectedData: selectedData,
                handleGet: handleGet
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "offcanvas offcanvas-end",
                tabIndex: "-1",
                id: "searchOptions",
                "aria-labelledby": "searchOptionsLabel",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "offcanvas-header",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "offcanvas-title",
                                id: "searchOptionsLabel",
                                children: "Search Options"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "btn-close text-reset",
                                "data-bs-dismiss": "offcanvas",
                                "aria-label": "Close"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "offcanvas-body",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "btn btn-outline-primary rounded-0",
                                children: "Lakukan Pencarian"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;