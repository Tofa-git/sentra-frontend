"use strict";
exports.id = 8694;
exports.ids = [8694];
exports.modules = {

/***/ 8694:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_input__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7267);
/* harmony import */ var _components_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2857);
/* harmony import */ var _context_country_reducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3363);
/* harmony import */ var _context_nationality_reducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6821);
/* harmony import */ var _context_city_reducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8796);
/* harmony import */ var _context_cityLocation_reducer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4882);
/* harmony import */ var _context_book_actions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2611);
/* harmony import */ var _context_book_reducer__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4682);
/* harmony import */ var _context_auth_reducer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1118);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _context_auth_actions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7717);
/* harmony import */ var _context_constant__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6552);
/* harmony import */ var _utlis_helper__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5247);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_book_actions__WEBPACK_IMPORTED_MODULE_8__, _context_auth_actions__WEBPACK_IMPORTED_MODULE_13__]);
([_context_book_actions__WEBPACK_IMPORTED_MODULE_8__, _context_auth_actions__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const initialForm = {
    checkIn: "",
    checkOut: "",
    lowestPriceOnly: true,
    nationality: "ID",
    currency: "IDR",
    country: "",
    city: "",
    cityCode: "1704",
    adultSG: 0,
    adultDB: 0,
    adultTW: 0,
    adultTP: 0,
    adultQD: 0,
    adults: 0,
    adult: 0,
    children: 0,
    childAge: 0,
    roomNo: 1,
    codeHotel: "",
    night: 0
};
const ratingsData = [
    {
        id: 1,
        name: "★"
    },
    {
        id: 2,
        name: "★★"
    },
    {
        id: 3,
        name: "★★★"
    },
    {
        id: 4,
        name: "★★★★"
    },
    {
        id: 5,
        name: "★★★★★"
    }
];
const roomData = new Array(Number(31)).fill().map((i, key)=>({
        id: key + 1,
        name: key + 1
    }));
const Index = (props)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_12__.useRouter)();
    const [selectedHotel, setSelectedHotel] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [selectedRoom, setSelectedRoom] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [selectedAgent, setSelectedAgent] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [roomHotelData, setRoomHotelData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [recheckData, setRecheckData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [guestData, setGuestData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [sessionId, setSessionId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [request, setRequest] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [bookRequest, setBookRequest] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [supplierCode, setSupplierCode] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_book_reducer__WEBPACK_IMPORTED_MODULE_9__/* .BookContext */ .m);
    const { state: cityState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_city_reducer__WEBPACK_IMPORTED_MODULE_6__/* .CityContext */ .i);
    const { state: countryState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_country_reducer__WEBPACK_IMPORTED_MODULE_4__/* .CountryContext */ .o);
    const { state: nationalityState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_nationality_reducer__WEBPACK_IMPORTED_MODULE_5__/* .NationalityContext */ .M);
    const { state: cityLocationState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_cityLocation_reducer__WEBPACK_IMPORTED_MODULE_7__/* .CityLocationContext */ .O);
    const { state: authState , dispatch: authDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_reducer__WEBPACK_IMPORTED_MODULE_10__/* .AuthContext */ .V);
    const [form, setForm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialForm);
    const handleInputChange = (name, value)=>{
        let current = [
            ...guestData
        ];
        switch(name){
            case "adultSG":
                const sg = name === "adultSG" ? value : form.adultSG;
                setForm({
                    ...form,
                    [name]: value,
                    adults: form.adults += sg
                });
                setForm({
                    ...form,
                    [name]: value,
                    adult: form.adults += sg
                });
                current.push({
                    room: `SG ${value}`,
                    salutation: "",
                    firstName: "",
                    lastName: "",
                    age: ""
                });
                break;
            case "adultDB":
                const db = name === "adultDB" ? value : form.adultDB;
                setForm({
                    ...form,
                    [name]: value,
                    adults: form.adults += db + 1
                });
                setForm({
                    ...form,
                    [name]: value,
                    adult: form.adult += db
                });
                current.push({
                    room: `DB ${value}`,
                    salutation: "",
                    firstName: "",
                    lastName: "",
                    age: ""
                });
                break;
            case "adultTW":
                const tw = name === "adultTW" ? value : form.adultTW;
                setForm({
                    ...form,
                    [name]: value,
                    adults: form.adults += tw + 1
                });
                setForm({
                    ...form,
                    [name]: value,
                    adult: form.adult += tw
                });
                break;
            case "adultTP":
                const tp = name === "adultTP" ? value : form.adultTP;
                setForm({
                    ...form,
                    [name]: value,
                    adults: form.adults += tp + 2
                });
                setForm({
                    ...form,
                    [name]: value,
                    adult: form.adult += tp
                });
                break;
            case "adultQD":
                const qd = name === "adultQD" ? value : form.adultQD;
                setForm({
                    ...form,
                    [name]: value,
                    adults: form.adults += qd + 3
                });
                setForm({
                    ...form,
                    [name]: value,
                    adult: form.adult += qd
                });
                break;
            case "checkOut":
                const checkInDate = name === "checkIn" ? value : form.checkIn;
                const checkOutDate = name === "checkOut" ? value : form.checkOut;
                const nightCount = calculateNightCount(checkInDate, checkOutDate);
                setForm({
                    ...form,
                    [name]: value,
                    night: nightCount
                });
                break;
            default:
                // Code to execute when name doesn't match any of the cases
                setForm({
                    ...form,
                    [name]: value
                });
        }
        ;
        setGuestData(current);
    };
    const calculateNightCount = (checkInDate, checkOutDate)=>{
        if (checkInDate && checkOutDate) {
            const oneDay = 24 * 60 * 60 * 1000; // One day in milliseconds
            const checkIn = new Date(checkInDate);
            const checkOut = new Date(checkOutDate);
            const nightCount = Math.round(Math.abs((checkIn - checkOut) / oneDay));
            return nightCount;
        }
        return 0;
    };
    const handleGuestChange = (id, name, value)=>{
        let current = [
            ...guestData
        ];
        current[id][name] = value;
        setGuestData(current);
    };
    const handleGet = async ()=>{
        setSelectedHotel({});
        setSelectedRoom({});
        setRecheckData(null);
        sweetalert2__WEBPACK_IMPORTED_MODULE_11___default().fire({
            icon: "info",
            title: "Search Available Hotel",
            showConfirmButton: false,
            timer: 1000 * 60,
            timerProgressBar: true,
            didOpen: ()=>{
                sweetalert2__WEBPACK_IMPORTED_MODULE_11___default().showLoading();
            }
        });
        const book = await (0,_context_book_actions__WEBPACK_IMPORTED_MODULE_8__/* .getAllBookSearch */ .IZ)(dispatch, form);
        if (book.status === 401) {
            authDispatch({
                type: AUTH_401
            });
            authDispatch({
                type: AUTH_LOGOUT
            });
            sweetalert2__WEBPACK_IMPORTED_MODULE_11___default().fire("Token has been Expired", "Please Login Again", "warning");
            router.push("/authentication/login");
        }
        setTimeout(()=>{
            sweetalert2__WEBPACK_IMPORTED_MODULE_11___default().close();
        }, 1500);
    };
    const handleRoomGet = async (data, supplierId)=>{
        sweetalert2__WEBPACK_IMPORTED_MODULE_11___default().fire({
            icon: "info",
            title: "Search Available Room",
            showConfirmButton: false,
            timer: 1000 * 60,
            timerProgressBar: true,
            didOpen: ()=>{
                sweetalert2__WEBPACK_IMPORTED_MODULE_11___default().showLoading();
            }
        });
        const body = {
            ...data,
            checkIn: form.checkIn,
            checkOut: form?.checkOut,
            nationality: form?.nationality,
            currency: form?.currency,
            realTimeRoom: 1,
            realTimeValue: 0,
            realTimeAdult: 1
        };
        const _recheck = await (0,_context_book_actions__WEBPACK_IMPORTED_MODULE_8__/* .getAllBookSearchRoom */ .$C)(body, supplierId);
        setRoomHotelData(_recheck.data.data.rooms);
        setTimeout(()=>{
            sweetalert2__WEBPACK_IMPORTED_MODULE_11___default().close();
        }, 1500);
    };
    const handleRecheck = async (room)=>{
        setSelectedRoom(room);
        sweetalert2__WEBPACK_IMPORTED_MODULE_11___default().fire({
            icon: "info",
            title: "Checking Available Room",
            showConfirmButton: false,
            timer: 1000 * 60,
            timerProgressBar: true,
            didOpen: ()=>{
                sweetalert2__WEBPACK_IMPORTED_MODULE_11___default().showLoading();
            }
        });
        const body = {
            ...form,
            supplierId: selectedHotel.supplierId,
            hotelCode: selectedHotel.code,
            hotelName: selectedHotel.name,
            sessionId: sessionId,
            roomCode: room?.code,
            mealPlan: room?.mealPlan,
            rateKey: room?.rooms?.room?.[0]?.rateKey,
            cancelPolicyType: room?.cancellationPolicyType
        };
        delete body.codeHotel;
        const _recheck = await (0,_context_book_actions__WEBPACK_IMPORTED_MODULE_8__/* .recheckBookSearch */ .yn)(body);
        setRecheckData(_recheck.data.data);
        if (_recheck.data.data.sessionId) {
            setSessionId(_recheck.data.data.sessionId);
        }
        setTimeout(()=>{
            sweetalert2__WEBPACK_IMPORTED_MODULE_11___default().close();
        }, 1500);
    };
    const handleBook = async ()=>{
        sweetalert2__WEBPACK_IMPORTED_MODULE_11___default().fire({
            icon: "info",
            title: "Booking Room",
            showConfirmButton: false,
            timer: 1000 * 60,
            timerProgressBar: true,
            didOpen: ()=>{
                sweetalert2__WEBPACK_IMPORTED_MODULE_11___default().showLoading();
            }
        });
        const body = {
            ...form,
            hotelCode: selectedHotel.code,
            supplierId: selectedHotel.supplierId,
            sessionId: sessionId,
            roomCode: selectedRoom?.code,
            mealPlan: selectedRoom?.mealPlan,
            request: bookRequest != "" ? bookRequest + ";" + request : request,
            rateKey: selectedRoom?.rooms?.room?.[0]?.rateKey,
            cancelPolicyType: selectedRoom?.cancellationPolicyType,
            guests: guestData,
            contact: {
                nameFirst: "Agung",
                nameLast: "Wicaksono",
                phone: "6281233661927",
                email: "wicaksono1404@gmail.com"
            },
            agent: selectedAgent
        };
        delete body.codeHotel;
        await (0,_context_book_actions__WEBPACK_IMPORTED_MODULE_8__/* .createBook */ .IY)(body);
    // setTimeout(() => {
    //   Swal.close();
    //   setSelectedHotel({});
    //   setSelectedRoom({});
    //   setRecheckData(null);
    //   setSelectedAgent({});
    //   setGuestData([]);
    //   setForm(initialForm);
    // }, 4500);
    };
    const handleReset = ()=>{
        dispatch({
            type: _context_constant__WEBPACK_IMPORTED_MODULE_14__/* .BOOK_SEARCH_RESET */ .MH
        });
        setForm(initialForm);
        setSelectedHotel({});
        setSelectedRoom({});
        setRecheckData(null);
        setSelectedAgent({});
        setGuestData([]);
    };
    // Function to handle checkbox changes
    const handleCheckboxChange = (e)=>{
        // Get the text from the adjacent span element
        const text = e.target.nextElementSibling.textContent.trim();
        // Update the selectedOptions state with the new value
        setRequest((prevSelectedOptions)=>{
            // Check if the checkbox is checked
            if (e.target.checked) {
                // Append the text to the existing selectedOptions with a semicolon separator
                if (prevSelectedOptions.length === 0) {
                    return text;
                } else {
                    return prevSelectedOptions + ";" + text;
                }
            } else {
                // Remove the text from the selectedOptions if the checkbox is unchecked
                return prevSelectedOptions.replace(new RegExp(text + ";?", "g"), "");
            }
        });
    };
    // Function to handle textarea changes
    const handleTextareaChange = (e)=>{
        // Get the value from the textarea
        const text = e.target.value;
        // Update the bookRequest state with the new value
        setBookRequest(text);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_context_auth_actions__WEBPACK_IMPORTED_MODULE_13__/* .getAllUserDD */ .x)(authDispatch);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
    // let current = [...guestData];
    // if (+form.adults < current.length) {
    //   current =
    //     current.length === 0 ? [] : current.slice(0, current.length - 1);
    // } else {
    //   if (+form.adults !== 0) {
    //     for (let i = current.length; i < +form.adults; i++) {
    //       current.push({
    //         room: "",
    //         salutation: "",
    //         firstName: "",
    //         lastName: "",
    //         age: "",
    //       });
    //     }
    //   }
    // }
    // setGuestData(current);
    }, [
        form.adults
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "mx-3",
        children: [
            console.log({
                guestData
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row p-3",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "col-lg-6",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-dark mb-1",
                                children: "Booking"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-white py-3 row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "Agent",
                                            options: authState?.listUsers,
                                            onChange: (val)=>{
                                                const user = authState?.listUsers?.find((i)=>i.id === Number(val.value));
                                                setSelectedAgent(user);
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "Nationality",
                                            target: "general",
                                            // value={form.nationality}
                                            options: nationalityState?.dropdownData,
                                            onChange: (val)=>handleInputChange("nationality", "ID")
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "Country",
                                            target: "general",
                                            value: form.country,
                                            options: countryState?.dropdownData,
                                            onChange: (val)=>{
                                                handleInputChange("country", val?.target.value);
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "City",
                                            target: "general",
                                            value: form.city,
                                            options: cityState?.dropdownData,
                                            onChange: (val)=>handleInputChange("city", val.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            type: "date",
                                            label: "Check In",
                                            value: form.checkIn,
                                            onChange: (val)=>handleInputChange("checkIn", val)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            type: "date",
                                            label: "Check Out",
                                            disabled: form.checkIn ? true : false,
                                            value: form.checkOut,
                                            onChange: (val)=>handleInputChange("checkOut", val)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            type: "number",
                                            label: "Night",
                                            value: form.night,
                                            readOnly: true
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            options: ratingsData
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            options: roomData,
                                            label: "SG",
                                            value: form.adultSG,
                                            onChange: (val)=>{
                                                handleInputChange("adultSG", +val.target.value);
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            options: roomData,
                                            label: "DB",
                                            value: form.adultDB,
                                            onChange: (val)=>{
                                                handleInputChange("adultDB", +val.target.value);
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            options: roomData,
                                            label: "TW",
                                            value: form.adultTW,
                                            onChange: (val)=>{
                                                handleInputChange("adultTW", +val.target.value);
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            options: roomData,
                                            label: "TP",
                                            value: form.adultTP,
                                            onChange: (val)=>{
                                                handleInputChange("adultTP", +val.target.value);
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            options: roomData,
                                            label: "QD",
                                            value: form.adultQD,
                                            onChange: (val)=>{
                                                handleInputChange("adultQD", +val.target.value);
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Rooms",
                                            type: "number",
                                            value: form.roomNo,
                                            onChange: (val)=>handleInputChange("roomNo", val.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "City Location",
                                            target: "home",
                                            value: form.cityLocation,
                                            options: cityLocationState?.dropdownData,
                                            onChange: (val)=>handleInputChange("cityLocation", val.target.value)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "Hotel"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-8",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Designate Hotel"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-4 align-items-end d-flex",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                disabled: state.isLoading,
                                                onClick: ()=>handleGet(form),
                                                className: "btn bg-blue rounded text text-white",
                                                children: "Search"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>handleReset(),
                                                className: "btn bg-blue rounded ms-2 text-white",
                                                children: "Reset"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-8",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Quick Search"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-4 align-items-end d-flex",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "btn bg-blue rounded text-white",
                                            children: "Search"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "text-dark mt-2 mb-2",
                                                children: "Available Type"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "radio"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Available"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "radio",
                                                className: "ms-2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "ALL"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-12",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "text-dark mt-2 mb-2",
                                                children: "Sort"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "radio"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "RT + Rate"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "radio",
                                                className: "ms-2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Low Price"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "radio",
                                                className: "ms-2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Grade"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "radio",
                                                className: "ms-2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Hotel"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                className: "ms-2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Tarif"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-12",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "text-dark mt-2 mb-2",
                                                children: "XML Supplier"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                className: "ms-2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "ALL"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                className: "ms-2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "HBE"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                className: "ms-2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "MGJ"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-dark mb-1 mt-4",
                                children: "Hotel List"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "bg-white",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                    className: "table table-bordered table-hover table-striped",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "bg-blue text-white",
                                                        width: "5%",
                                                        children: "Code"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "bg-blue text-white",
                                                        width: "30%",
                                                        children: "Hotel"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "bg-blue text-white",
                                                        width: "5%",
                                                        children: "★"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "bg-blue text-white",
                                                        width: "5%",
                                                        children: "Net Price"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "bg-blue text-white",
                                                        width: "5%",
                                                        children: "Supplier"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                            children: state?.data?.hotels.map((data)=>{
                                                const isSelected = data.code === selectedHotel?.code;
                                                const sortedData = data?.roomDetails?.sort((a, b)=>a.grossPrice - b.grossPrice)[0];
                                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    onClick: ()=>{
                                                        setSelectedHotel(data);
                                                        setSelectedRoom({});
                                                        setRecheckData(null);
                                                        if (data.roomDetails.length == 0) {
                                                            handleRoomGet(data, data.supplierId);
                                                            setSupplierCode(data.supplierCode);
                                                        } else {
                                                            setRoomHotelData(data.roomDetails);
                                                            setSupplierCode(data.supplierCode);
                                                            setSessionId(data.sessionId);
                                                        }
                                                    },
                                                    className: `${isSelected ? "bg-selected" : ""} pointer`,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: data.code
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: data.name
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: data.rating
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: (0,_utlis_helper__WEBPACK_IMPORTED_MODULE_15__/* .toIDR */ .y)(data.netPrice)
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: data.supplierCode
                                                        })
                                                    ]
                                                });
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "col-lg-6",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-dark mb-1",
                                children: "Hotel"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-3 px-2 py-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Supply"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                        className: "table table-bordered table-hover table-striped",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "Code"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "20%",
                                                            children: "Name"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "10%",
                                                            children: "Gross Price"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "10%",
                                                            children: "Net Price"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "Plan"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "Supplier"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                children: roomHotelData?.map((data)=>{
                                                    const isSelected = data.id === selectedRoom?.id;
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        onClick: ()=>handleRecheck(data),
                                                        className: `${isSelected ? "bg-selected" : ""} pointer`,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: data.code
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: data.name
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: (0,_utlis_helper__WEBPACK_IMPORTED_MODULE_15__/* .toIDR */ .y)(data.grossPrice)
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: (0,_utlis_helper__WEBPACK_IMPORTED_MODULE_15__/* .toIDR */ .y)(data.netPrice)
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: data.mealPlanName
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                children: supplierCode
                                                            })
                                                        ]
                                                    });
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "text-dark mb-1",
                                children: [
                                    "Rate: ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-primary",
                                        children: selectedRoom?.name
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "bg-white",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                    className: "table table-bordered table-hover table-striped",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("thead", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {}),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "text-center bg-blue text-white",
                                                            colSpan: 5,
                                                            children: "Sale"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "text-center bg-blue text-white",
                                                            colSpan: 5,
                                                            children: "Net"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "Date"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "SGL"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "DBL"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "TWN"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "TRP"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "QUAD"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "SGL"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "DBL"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "TWN"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "TRP"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "bg-blue text-white",
                                                            width: "5%",
                                                            children: "QUAD"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: recheckData ? form.checkIn : "-"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: "0"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: recheckData?.roomDetails ? (0,_utlis_helper__WEBPACK_IMPORTED_MODULE_15__/* .toIDR */ .y)(recheckData?.roomDetails?.grossPrice) : 0
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: "0"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: "0"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: "0"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: "0"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: recheckData?.roomDetails ? (0,_utlis_helper__WEBPACK_IMPORTED_MODULE_15__/* .toIDR */ .y)(recheckData?.roomDetails?.netPrice) : 0
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: "0"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: "0"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: "0"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "text-primary text-center",
                                                            colSpan: 3,
                                                            children: "CXL DEADLINE"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "text-danger text-center",
                                                            colSpan: 3,
                                                            children: recheckData?.roomDetails?.cancellationPolicies?.policy?.[0]?.fromDate || "Non Refundable"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "text-primary text-center",
                                                            colSpan: 3,
                                                            children: "SPLY DEADLINE"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "text-danger text-center",
                                                            colSpan: 3,
                                                            children: recheckData?.roomDetails?.cancellationPolicies?.policy?.[recheckData?.roomDetails?.cancellationPolicies?.policy?.length - 1]?.toDate || "-"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "text-dark mb-1 d-flex justify-content-between",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Booking"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "btn bg-blue rounded-1 text-white ms-2",
                                                children: "Wish"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "btn bg-blue rounded-1 text-white ms-2",
                                                children: "Quotation"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-white row mx-0 py-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Group No"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Book No",
                                            disabled: true
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Book Type",
                                            value: "internal",
                                            disabled: true
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Agent",
                                            value: selectedAgent?.firstName,
                                            disabled: true
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Manager",
                                            disabled: true
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Markup",
                                            value: "Net + 0  or  Net \xd7 0%",
                                            disabled: true
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Credit",
                                            value: "0.00 / 0.00 (IDR)",
                                            disabled: true
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Tel"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Mobile",
                                            value: selectedAgent?.mobile
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Email",
                                            value: selectedAgent?.email
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-6",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Operator",
                                            disabled: true
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "If Over (no) Credit",
                                            disabled: true,
                                            value: "Book only before CXL dead line"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "bg-white mt-2",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                    className: "table table-bordered table-hover table-striped",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "bg-blue text-white",
                                                        width: "5%",
                                                        children: "Room"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "bg-blue text-white",
                                                        width: "5%",
                                                        children: "First Name"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "bg-blue text-white",
                                                        width: "5%",
                                                        children: "Last Name"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "bg-blue text-white",
                                                        width: "5%",
                                                        children: "Salutation"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "bg-blue text-white",
                                                        width: "5%",
                                                        children: "Age"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                            children: guestData.map((data, key)=>{
                                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                value: data.room,
                                                                onChange: (val)=>handleGuestChange(key, "room", val.target.value)
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                value: data.firstName,
                                                                onChange: (val)=>handleGuestChange(key, "firstName", val.target.value)
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                value: data.lastName,
                                                                onChange: (val)=>handleGuestChange(key, "lastName", val.target.value)
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                value: data.salutation,
                                                                style: {
                                                                    minHeight: 30
                                                                },
                                                                onChange: (val)=>handleGuestChange(key, "salutation", val.target.value),
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        children: "== Select =="
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "Mr",
                                                                        children: "Mr"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                        value: "Mrs",
                                                                        children: "Mrs"
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                value: data.age,
                                                                onChange: (val)=>handleGuestChange(key, "age", val.target.value)
                                                            })
                                                        })
                                                    ]
                                                });
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-danger mb-1",
                                children: "** Bed Type may not be guaranteed **"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-white row mx-0 py-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 text-dark fw-bold mb-2",
                                        children: "Add Request"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                onChange: handleCheckboxChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Honeymoon"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                onChange: handleCheckboxChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Non-Smoking Room"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                onChange: handleCheckboxChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Smoking Room Request"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                onChange: handleCheckboxChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Interconnecting rooms"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                onChange: handleCheckboxChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Adjoinning rooms"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Early checkin-at"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                className: "form-select rounded-0 text-white",
                                                value: "-",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "-",
                                                        selected: true,
                                                        disabled: true,
                                                        children: "Choose Hours"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "1",
                                                        selected: true,
                                                        children: "Indonesia"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "0",
                                                        selected: true,
                                                        children: "Singapore"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Late checkin-at"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                className: "form-select rounded-0 text-white",
                                                value: "-",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "-",
                                                        selected: true,
                                                        disabled: true,
                                                        children: "Choose Hours"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "1",
                                                        selected: true,
                                                        children: "Indonesia"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "0",
                                                        selected: true,
                                                        children: "Singapore"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                onChange: handleCheckboxChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "King size bed request"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                onChange: handleCheckboxChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Share bed child request"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Share bed child age"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "number",
                                                className: "form-control"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                onChange: handleCheckboxChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Bath tube request"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox",
                                                onChange: handleCheckboxChange
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-dark ms-2",
                                                children: "Hight Speed Internet"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 text-dark fw-bold mt-2",
                                        children: "Book Request"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                            className: "form-control",
                                            value: bookRequest,
                                            onChange: handleTextareaChange
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 text-dark fw-bold mt-2",
                                        children: "Internal Remark"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                            className: "form-control"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-12 d-flex justify-content-end py-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>handleBook(),
                                                className: "btn bg-blue rounded-1 text-white ms-2",
                                                children: "Book"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "btn bg-blue rounded-1 text-white ms-2",
                                                children: "Reset"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5247:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ toIDR)
/* harmony export */ });
const toIDR = (price)=>{
    return new Intl.NumberFormat().format(price);
};


/***/ })

};
;