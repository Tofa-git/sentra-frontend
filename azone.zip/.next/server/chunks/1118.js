"use strict";
exports.id = 1118;
exports.ids = [1118];
exports.modules = {

/***/ 1118:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ AuthContextProvider),
/* harmony export */   "V": () => (/* binding */ AuthContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);



const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
const initialState = {
    isAuthenticated: false,
    isLoading: false,
    isError: false,
    errorMessage: null,
    status: 200,
    listUsers: []
};
function reducer(state, action) {
    switch(action.type){
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .AUTH_PROCESS */ .L3:
            return {
                ...state,
                isLoading: true
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .AUTH_SUCCESS */ .DP:
            return {
                ...state,
                isLoading: false,
                isAuthenticated: true,
                isError: false,
                errorMessage: null,
                status: 200
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .AUTH_FAILED */ .v$:
            return {
                ...state,
                isLoading: false,
                isAuthenticated: false,
                isError: true,
                errorMessage: action.payload
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .AUTH_LOGOUT */ .LQ:
            localStorage.removeItem("AUTH_TOKEN");
            return {
                ...state,
                isLoading: false,
                isAuthenticated: false,
                isError: false,
                errorMessage: null,
                status: 200
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .AUTH_401 */ .fR:
            return {
                ...state,
                status: 401
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .GET_USER_PROCESS */ .KT:
            return {
                ...state,
                isLoading: true
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .GET_USER_SUCCESS */ .VV:
            return {
                ...state,
                isLoading: false,
                listUsers: action.payload.data
            };
        case _constant__WEBPACK_IMPORTED_MODULE_2__/* .GET_USER_FAILED */ .P0:
            return {
                ...state,
                isLoading: false,
                isError: true,
                errorMessage: action.payload
            };
        default:
            return state;
    }
}
function AuthContextProvider({ children  }) {
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, initialState);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthContext.Provider, {
        value: {
            state,
            dispatch
        },
        children: children
    });
}



/***/ })

};
;