"use strict";
exports.id = 359;
exports.ids = [359];
exports.modules = {

/***/ 359:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_input__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7267);
/* harmony import */ var _components_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2857);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _context_book_actions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2611);
/* harmony import */ var _context_auth_reducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1118);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _context_book_reducer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4682);
/* harmony import */ var _components_pagination__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9455);
/* harmony import */ var _modalDetail__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4398);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_book_actions__WEBPACK_IMPORTED_MODULE_5__, _modalDetail__WEBPACK_IMPORTED_MODULE_10__]);
([_context_book_actions__WEBPACK_IMPORTED_MODULE_5__, _modalDetail__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const checklist = [
    {
        id: 0,
        value: "ALL"
    },
    {
        id: 1,
        value: "Err Notes"
    },
    {
        id: 3,
        value: "On Process"
    },
    {
        id: 4,
        value: "Pay Failed"
    },
    {
        id: 5,
        value: "Request"
    },
    {
        id: 6,
        value: "Confirm"
    },
    {
        id: 7,
        value: "Amendrq"
    },
    {
        id: 8,
        value: "Amendrs"
    },
    {
        id: 9,
        value: "Cxlrq"
    },
    {
        id: 10,
        value: "Canceled"
    },
    {
        id: 11,
        value: "Reject"
    },
    {
        id: 12,
        value: "Sply Check"
    },
    {
        id: 13,
        value: "Vouchered"
    },
    {
        id: 14,
        value: "Mismatched Status"
    },
    {
        id: 15,
        value: "Hotel Name"
    },
    {
        id: 16,
        value: "Hotem Name"
    }
];
const Index = (props)=>{
    const { setMode  } = props;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const [keyword, setKeyword] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [detailBooking, setDetailBooking] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_book_reducer__WEBPACK_IMPORTED_MODULE_8__/* .BookContext */ .m);
    const { dispatch: authDispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_reducer__WEBPACK_IMPORTED_MODULE_6__/* .AuthContext */ .V);
    const handleGet = async (page = 1, limit = 12)=>{
        const country = await (0,_context_book_actions__WEBPACK_IMPORTED_MODULE_5__/* .getAllBookList */ .Ar)(dispatch, page, limit, keyword);
        if (country.status === 401) {
            authDispatch({
                type: AUTH_401
            });
            authDispatch({
                type: AUTH_LOGOUT
            });
            sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().fire("Token has been Expired", "Please Login Again", "warning");
            router.push("/authentication/login");
        }
    };
    const handleDetail = async (bookId)=>{
        setDetailBooking({});
        sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().fire({
            icon: "info",
            title: "Get Detail Book" + `: ${bookId}`,
            showConfirmButton: false,
            timer: 1000 * 60,
            timerProgressBar: true,
            didOpen: ()=>{
                sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().showLoading();
            }
        });
        const book = await (0,_context_book_actions__WEBPACK_IMPORTED_MODULE_5__/* .getDetailBook */ .vI)(dispatch, bookId);
        if (book.status === 401) {
            authDispatch({
                type: AUTH_401
            });
            authDispatch({
                type: AUTH_LOGOUT
            });
            sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().fire("Token has been Expired", "Please Login Again", "warning");
            router.push("/authentication/login");
        }
        setMode(2);
        setDetailBooking(book.data.data);
        setTimeout(()=>{
            sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().close();
        }, 1500);
    };
    const handleCancel = async (id)=>{
        sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().fire({
            title: "Are you sure?",
            text: `You will cancel ${id}, you won't revert this`,
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, Cancel Booking"
        }).then(async (result)=>{
            if (result.isConfirmed) {
                sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().fire({
                    icon: "info",
                    title: "Canceling Booking" + `: ${id}`,
                    showConfirmButton: false,
                    timer: 1000 * 60,
                    timerProgressBar: true,
                    didOpen: ()=>{
                        sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().showLoading();
                    }
                });
                const res = await (0,_context_book_actions__WEBPACK_IMPORTED_MODULE_5__/* .cancelBooking */ .d$)(id);
                if (res.status === 500) {
                    sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().fire("Error Canceling Book", res.message, "error");
                } else {
                    sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().fire("Successfully Cancel Book", "", "success");
                }
                setTimeout(()=>{
                    sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().close();
                }, 1500);
            }
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        handleGet();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "m-3",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modalDetail__WEBPACK_IMPORTED_MODULE_10__["default"], {
                id: "createHotel",
                size: "modal-xl",
                handleGet: handleGet,
                data: detailBooking
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "d-flex h-100",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-100",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-dark mb-2",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "material-icons text-dark",
                                        style: {
                                            verticalAlign: "middle"
                                        },
                                        children: "arrow_right"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ms-2 text-dark",
                                        children: "Booking Search (Request : 0 / Amendreq : 0 / Amendrs : 0 / Cancelreq : 0 / Reject : 2 / Sply Check : 0 / Mis-matched Status : 0 / HotelName Alert : 0 /1 ) Date Format(YY-MM-DD)"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mb-3 mx-3",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-white py-3 row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "Period"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "d-flex flex-row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    label: "Start"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    label: "End"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "d-flex flex-row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    label: "Type Book"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    label: ""
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Suplier"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Guest Name"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Hotel Name"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "Type"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "First Operator"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "Last Operator"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Agent"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Manager"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "Supplier"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "Select Office"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            label: "Booking"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "Country"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_input__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            label: "City"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-12",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "text-dark mt-2 mb-1",
                                                children: "Status"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "row",
                                                children: checklist.map((i)=>{
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-2",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "checkbox",
                                                                className: "ms-2"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "text-dark ms-2",
                                                                children: i.value
                                                            })
                                                        ]
                                                    });
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-3",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "d-flex flex-row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    label: "Client Type"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "bg-blue text-white rounded ms-2 h-50 align-self-end",
                                                    children: "Search"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "bg-blue text-white rounded ms-2 h-50 align-self-end",
                                                    children: "Excel"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-dark mb-2",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "material-icons text-dark",
                                        style: {
                                            verticalAlign: "middle"
                                        },
                                        children: "arrow_right"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ms-2 text-dark",
                                        children: "Booking List [EVT: P(minus Profit), D(Double book), O(Over credit limit), E(Promotion), A(Allotment Confirm), R(Hotel's Rmk), G (Guest's Rmk), H (Hotel Cnf No), V (Voucher Issued), C (Compare Book) , W (Voucher for hotel)]"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: {
                                background: "#fff"
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                className: "table table-bordered table-hover table-striped",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "bg-blue text-white",
                                                    width: "auto",
                                                    children: "Booking ID"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "bg-blue text-white",
                                                    width: "auto",
                                                    children: "Supplier"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "bg-blue text-white",
                                                    width: "auto",
                                                    children: "Check In"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "bg-blue text-white",
                                                    width: "auto",
                                                    children: "Check Out"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "bg-blue text-white",
                                                    width: "15%",
                                                    children: "Hotel Name"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "bg-blue text-white",
                                                    width: "auto",
                                                    children: "Gross Price"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "bg-blue text-white",
                                                    width: "auto",
                                                    children: "Policy Type"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "bg-blue text-white",
                                                    width: "auto",
                                                    children: "Room Name"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "bg-blue text-white",
                                                    width: "auto",
                                                    children: "Status"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "bg-blue text-white",
                                                    width: "auto",
                                                    children: "Action"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                        children: state?.dataList?.rows?.map((data)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: data?.mgBookingID
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: data?.supplier.code
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: data?.checkIn
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: data?.checkOut
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: data?.hotelName
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: data?.grossPrice
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: data?.cancellationPolicyType
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: data?.roomName
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        children: data?.bookingStatus
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                        className: "d-flex flex-row justify-content-center align-items-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                type: "button",
                                                                className: "btn btn-primary bg-blue",
                                                                onClick: ()=>handleDetail(data?.mgBookingID),
                                                                children: "Detail"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                type: "button",
                                                                className: "btn btn-danger ms-2",
                                                                onClick: ()=>{
                                                                    handleCancel(data?.mgBookingID);
                                                                },
                                                                children: "Cancel"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            });
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_pagination__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            state: state?.dataList,
                            handleGet: handleGet
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;