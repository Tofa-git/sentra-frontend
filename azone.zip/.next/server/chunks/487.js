"use strict";
exports.id = 487;
exports.ids = [487];
exports.modules = {

/***/ 487:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cB": () => (/* binding */ updateHotel),
/* harmony export */   "cT": () => (/* binding */ uploadFile),
/* harmony export */   "dZ": () => (/* binding */ createHotel),
/* harmony export */   "ks": () => (/* binding */ getAllHotel)
/* harmony export */ });
/* unused harmony export deleteHotel */
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const getAllHotel = async (dispatch, isDropDown = false, page = 1, limit = 12, name = "")=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .HOTEL_PROCESS */ .ZJ
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/hotel?page=${page}&limit=${limit}`;
        if (name.length > 0) {
            url += `&name=${name}`;
        }
        if (isDropDown) {
            url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/hotel-dd`;
        }
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .HOTEL_SUCCESS */ .Wx,
            payload: {
                data: data?.data,
                isDropDown
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .HOTEL_FAILED */ .W3,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
const createHotel = async (body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/hotel`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Create Success", "Hotel has been successfully created", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Create Failed", "Error when create hotel, please try again later", "error");
    }
};
const uploadFile = async (body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/file`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "multipart/form-data"
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Create Success", "Hotel has been successfully created", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Create Failed", "Error when create hotel, please try again later", "error");
    }
};
const updateHotel = async (id, body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/master/hotel/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"].put(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Update Success", "Hotel has been successfully updated", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Update Failed", "Error when update hotel, please try again later", "error");
    }
};
const deleteHotel = async (id)=>{
    try {
        const url = `${baseUrl}/api/master/hotel/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.delete(url, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Delete Success", "Hotel has been successfully deleted", "success");
    } catch (error) {
        Swal.fire("Delete Failed", "Error when delete hotel, please try again later", "error");
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;