"use strict";
exports.id = 7842;
exports.ids = [7842];
exports.modules = {

/***/ 7842:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HS": () => (/* binding */ getDDLCity),
/* harmony export */   "VA": () => (/* binding */ updateData),
/* harmony export */   "Yu": () => (/* binding */ getData),
/* harmony export */   "hL": () => (/* binding */ syncData)
/* harmony export */ });
/* unused harmony export createData */
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6552);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const getData = async (dispatch, isSync = false, page = 1, limit = 12, supplierId, name = "")=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_CITY_PROCESS */ .jX
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/show-mapcity?page=${page}&limit=${limit}`;
        let method = "GET";
        let body = null;
        if (name.length > 0) {
            url += `&name=${name}`;
        }
        if (isSync) {
            url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/show-mapcity?page=${page}&limit=${limit}`;
        } else {
            // Set the method to POST for synchronization
            method = "POST";
            body = JSON.stringify({
                supplierId: supplierId ?? 0
            });
        }
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: method,
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json"
            },
            body: body
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_CITY_SUCCESS */ .gK,
            payload: {
                data: data?.data,
                isSync
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_CITY_FAILED */ .B0,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
const syncData = async (dispatch, isSync = true, supplierId = 0)=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_CITY_PROCESS */ .jX
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/sync-mapcity/${supplierId}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_CITY_SUCCESS */ .gK,
            payload: {
                data: data?.data,
                isSync
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_CITY_FAILED */ .B0,
            payload: error?.response?.data?.message || "Error"
        });
    }
};
const createData = async (body)=>{
    try {
        const url = `${baseUrl}/api/integration/create-mapcity`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios.post(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        Swal.fire("Create Success", "Data has been successfully created", "success");
    } catch (error) {
        Swal.fire("Create Failed", "Error when create data, please try again later", "error");
    }
};
const updateData = async (id, body)=>{
    try {
        const url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/update-mapcity/${id}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        await axios__WEBPACK_IMPORTED_MODULE_1__["default"].put(url, body, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Update Success", "Data has been successfully updated", "success");
    } catch (error) {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Update Failed", "Error when update data, please try again later", "error");
    }
};
const getDDLCity = async (dispatch, countryId, supplierid, isDropDown = true)=>{
    dispatch({
        type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_CITY_PROCESS */ .jX
    });
    try {
        let url = `${_constant__WEBPACK_IMPORTED_MODULE_2__/* .baseUrl */ .FH}/api/integration/mapcity-dd?supplierId=${supplierid}&countryId=${countryId}`;
        const token = localStorage.getItem("AUTH_TOKEN");
        const config = {
            method: "POST",
            headers: {
                Authorization: `Bearer ${token}`
            }
        };
        const res = await fetch(url, config);
        const data = await res.json();
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_CITY_SUCCESS */ .gK,
            payload: {
                data: data?.data,
                isDropDown
            }
        });
        return {
            data: data?.data,
            status: res.status
        };
    } catch (error) {
        console.log(error);
        dispatch({
            type: _constant__WEBPACK_IMPORTED_MODULE_2__/* .MAPPING_CITY_FAILED */ .B0,
            payload: error?.response?.data?.message || "Error"
        });
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;